<?php
// POST /api/phones/invite: the main phone sends a copy of the shop and gets a join code to show as a QR.
// Authorization: Bearer <phone A's token>. The body is the copy of the shop itself (the app's backup file, as bytes).
// Answers {"ok", "code" (32 hex), "qr": "TILLO-JOIN:<code>", "expires_in" (seconds)}. One use, 10 minutes; a new
// code replaces any earlier one. Refused (409) while a second phone is joined: a shop has two phones at most.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
if ($phone['letter'] !== 'A') {
    json_error(403, 'Only the main phone can add a phone.');
}
expire_quiet_phones($storeId);
if (other_phone($storeId, 'A') !== null) {
    json_error(409, 'This shop already has 2 phones. Remove the other phone first.');
}
$bytes = read_bytes(MAX_SNAPSHOT_BYTES);

// A phone let go after 30 days makes room for the new one.
q("DELETE FROM phone_links WHERE store_id = ? AND letter <> 'A'", [$storeId]);
delete_old_joins($storeId, true);

$code = token(16);
$codeHash = hash('sha256', $code);
if (file_put_contents(snapshot_file($storeId, $codeHash), $bytes, LOCK_EX) === false) {
    json_error(500, 'Could not keep the copy of the shop. Try again.');
}
// The new phone takes the main phone's changes from here on: the copy has everything before.
$seq = (int)q('SELECT COALESCE(MAX(seq), 0) FROM phone_changes')->fetchColumn();
q('INSERT INTO phone_joins (code_hash, store_id, snapshot_seq, snapshot_bytes, expires_at, used_at) VALUES (?, ?, ?, ?, ?, NULL)',
    [$codeHash, $storeId, $seq, strlen($bytes), time() + JOIN_SECONDS]);

json_out(200, ['ok' => true, 'code' => $code, 'qr' => 'TILLO-JOIN:' . $code, 'expires_in' => JOIN_SECONDS]);
