<?php
// GET or POST /api/status: is this shop linked? Authorization: Bearer <token>.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';

$store = api_store();
json_out(200, [
    'ok' => true,
    'name' => $store['name'],
    'phone' => show_phone($store['phone']),
    'last_sync_at' => $store['last_sync_at'],
]);
