<?php
// POST /api/phones/list: the shop's phones, for the Phones screen. Authorization: Bearer <phone token>.
// Answers {"ok", "me": "A", "phones": [{"letter", "name", "last_seen" (seconds ago), "expired"}]}.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
expire_quiet_phones((int)$phone['store_id']);
json_out(200, ['ok' => true, 'me' => $phone['letter'], 'phones' => phone_list((int)$phone['store_id'])]);
