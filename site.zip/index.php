<?php
declare(strict_types=1);

require __DIR__ . '/lib/auth.php';

header('Location: ' . (config() !== null && owner_stores() ? '/reports' : '/login'));
