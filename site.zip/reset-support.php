<?php
// ONE-TIME support password reset (2026-11-17). Opened with the secret link (?t=...), it lets Tillo support type a new
// support password, saves its hash in the settings file and deletes itself. It stops working at RESET_UNTIL even if
// unused. Not part of the Tillo Cloud project: it was deployed once and is never deployed again.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

const RESET_HASH = 'f87f2d21ed5f5cb1de3ce725947fc6b776a1998a9b199c384c117cec3dfe292c';
const RESET_UNTIL = '2026-11-18 18:00:00';

$token = (string)($_POST['t'] ?? $_GET['t'] ?? '');
if (config() === null || time() > strtotime(RESET_UNTIL) || $token === '' || !hash_equals(RESET_HASH, hash('sha256', $token))) {
    sleep(2);
    http_response_code(404);
    exit('Not found.');
}

$error = null;
$done = false;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    check_csrf();
    $password = (string)($_POST['new_support'] ?? '');
    if (mb_strlen($password) < 10) {
        $error = 'Use at least 10 characters.';
    } elseif ($password !== (string)($_POST['again'] ?? '')) {
        $error = 'The two passwords are not the same.';
    } else {
        $config = config();
        $config['support_hash'] = password_hash($password, PASSWORD_DEFAULT);
        write_config($config);
        @unlink(__FILE__);
        $done = true;
    }
}

page_start('Reset support password');
?>
<section class="login">
    <h1>New support password</h1>
    <?php if ($done): ?>
        <div class="alert ok">Saved. This page is now deleted. <a href="/support">Sign in to support</a> with the new password.</div>
    <?php else: ?>
        <?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif ?>
        <form method="post" class="card form">
            <?= csrf_field() ?>
            <input type="hidden" name="t" value="<?= h($token) ?>">
            <label for="new_support">New support password (at least 10 characters)</label>
            <input id="new_support" name="new_support" type="password" autocomplete="new-password" minlength="10" required autofocus>
            <label for="again">Type it again</label>
            <input id="again" name="again" type="password" autocomplete="new-password" minlength="10" required>
            <button class="btn" type="submit">Save</button>
        </form>
    <?php endif ?>
</section>
<?php
page_end();
