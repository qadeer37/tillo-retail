<?php
// Insights: how new installations of Tillo Mobile get on, to see where shops stop before they sell and what helps them
// start. Counts and steps only (lib/steps.php): never shop names, cities, phone numbers or amounts. Each installation is
// a short ref made from its id (the same every time), so one can be followed from report to report.
//
// The report is written to insights/latest.txt and latest.json at most every 15 minutes, after a check-in (api/ping);
// that folder is never served (.htaccess), and Claude reads the files through Hostinger. Support sees it live at
// /api/insights.

declare(strict_types=1);

require_once __DIR__ . '/steps.php';

/** Seconds between two snapshots. */
const INSIGHTS_EVERY = 900;
const INSIGHTS_DIR = __DIR__ . '/../insights';

/** Setting up and selling, in the order a new shop meets them. */
const INSIGHTS_FUNNEL = ['start', 'setup', 'sell', 'cart', 'bill', 'bill10'];

/** Everything else a shop may try, the first time. */
const INSIGHTS_FEATURES = [
    'product', 'import', 'printer', 'print', 'whatsapp', 'customer', 'khata', 'purchase', 'expense', 'backup', 'phone2',
    'video', 'help', 'share', 'order', 'tab_products', 'tab_khata', 'tab_hisaab', 'tab_more',
];

/** An installation's ref: six letters of a hash of its id, the same in every report. */
function insights_ref(string $installId): string
{
    return substr(hash('sha256', 'tillo:' . $installId), 0, 6);
}

/** A share of [$of], as "42%" ("-" of none). */
function insights_pct(int $n, int $of): string
{
    return $of === 0 ? '-' : (string)round(100 * $n / $of) . '%';
}

/** The middle of [$values] (seconds), or null of none. */
function insights_median(array $values): ?int
{
    if ($values === []) {
        return null;
    }
    sort($values);
    $n = count($values);
    return $n % 2 === 1 ? $values[intdiv($n, 2)] : intdiv($values[$n / 2 - 1] + $values[$n / 2], 2);
}

/** Seconds as a short time: "45s", "12m", "3.5h", "2.1d". */
function insights_took(?int $secs): string
{
    if ($secs === null) {
        return '-';
    }
    if ($secs < 0) {
        return 'before';
    }
    if ($secs < 60) {
        return $secs . 's';
    }
    if ($secs < 3600) {
        return round($secs / 60) . 'm';
    }
    if ($secs < 86400) {
        return round($secs / 3600, 1) . 'h';
    }
    return round($secs / 86400, 1) . 'd';
}

/** Android's version as a band: old phones may struggle. */
function insights_android(?int $api): string
{
    return match (true) {
        $api === null || $api === 0 => '?',
        $api <= 28 => '9 or older',
        $api <= 30 => '10-11',
        $api <= 32 => '12',
        $api <= 34 => '13-14',
        default => '15+',
    };
}

/**
 * The report: who is active, and for the installations first seen in the last [$days] days, how far they got. Steps come
 * from Tillo Mobile 0.9.9 on; before them, what each check-in says (shop kind chosen, own products, a sale) still shows
 * the rough path.
 */
function insights_report(int $days = 14): array
{
    $days = max(1, min(60, $days));
    $now = time();
    $today = date('Y-m-d 00:00:00', $now);
    $week = date('Y-m-d H:i:s', $now - 7 * 86400);
    $month = date('Y-m-d H:i:s', $now - 30 * 86400);
    $since = date('Y-m-d 00:00:00', $now - ($days - 1) * 86400);

    $count = fn (string $where, array $params) => (int)q("SELECT COUNT(*) FROM installs WHERE app = 'mobile' AND $where", $params)->fetchColumn();
    $active = [
        'today' => $count('last_seen >= ?', [$today]),
        'days_7' => $count('last_seen >= ?', [$week]),
        'days_30' => $count('last_seen >= ?', [$month]),
        'selling_7d' => $count('last_seen >= ? AND bills_7d > 0', [$week]),
        'regular_7d' => $count('last_seen >= ? AND bills_7d >= 10', [$week]),
        'new_today' => $count('first_seen >= ?', [$today]),
        'new_7d' => $count('first_seen >= ?', [$week]),
    ];

    $installs = q(
        "SELECT install_id, app_version, version_code, android, kind, lang, phones, products, bills_today, bills_7d, last_sale_date,
                backup, online, days_seen, first_seen, last_seen, CASE WHEN shop_name IS NULL THEN 0 ELSE 1 END AS named
         FROM installs WHERE app = 'mobile' AND first_seen >= ? ORDER BY first_seen DESC LIMIT 5000",
        [$since],
    )->fetchAll();
    $steps = [];
    try {
        $rows = q(
            "SELECT s.install_id, s.step, s.secs FROM install_steps s JOIN installs i ON i.install_id = s.install_id
             WHERE i.app = 'mobile' AND i.first_seen >= ?",
            [$since],
        );
        foreach ($rows as $r) {
            $steps[$r['install_id']][$r['step']] = (int)$r['secs'];
        }
    } catch (PDOException) {
        // No steps yet (the table comes with the first one).
    }

    $sold = fn (array $i) => $i['last_sale_date'] !== null || (int)$i['bills_7d'] > 0;
    $blank = fn () => ['installs' => 0, 'set_up' => 0, 'named' => 0, 'own_products' => 0, 'sold' => 0, 'came_back' => 0, 'selling_7d' => 0];
    $add = function (array &$g, array $i) use ($sold, $week): void {
        $g['installs']++;
        $g['set_up'] += $i['kind'] !== null ? 1 : 0;
        $g['named'] += (int)$i['named'];
        $g['own_products'] += (int)$i['products'] > 3 ? 1 : 0;
        $g['sold'] += $sold($i) ? 1 : 0;
        $g['came_back'] += (int)$i['days_seen'] >= 2 ? 1 : 0;
        $g['selling_7d'] += $i['last_seen'] >= $week && (int)$i['bills_7d'] > 0 ? 1 : 0;
    };

    // Steps: new installations of 0.9.9 on, every one of them (one with no step at all never tapped Start). Not a shop
    // brought back from its backup or a second phone (they start elsewhere), nor one that was using Tillo before the
    // app kept steps (its steps are -1).
    $fresh = [];
    foreach ($installs as $i) {
        $s = $steps[$i['install_id']] ?? [];
        if ((int)$i['version_code'] < STEPS_FROM_CODE || isset($s['restore']) || isset($s['join']) || in_array(-1, $s, true)) {
            continue;
        }
        $fresh[] = $i + ['steps' => $s];
    }
    $freshIds = array_flip(array_column($fresh, 'install_id'));

    // What every check-in tells (all versions).
    $checkins = $blank();
    $byDay = [];
    $by = ['lang' => [], 'kind' => [], 'version' => [], 'android' => []];
    foreach ($installs as $i) {
        $add($checkins, $i);
        $day = substr((string)$i['first_seen'], 0, 10);
        $byDay[$day] ??= $blank() + ['with_steps' => 0, 'steps' => array_fill_keys(INSIGHTS_FUNNEL, 0)];
        $add($byDay[$day], $i);
        if (isset($freshIds[$i['install_id']])) {
            $byDay[$day]['with_steps']++;
            foreach (INSIGHTS_FUNNEL as $s) {
                $byDay[$day]['steps'][$s] += isset($steps[$i['install_id']][$s]) ? 1 : 0;
            }
        }
        foreach ([
            'lang' => $i['lang'] ?? '?', 'kind' => $i['kind'] ?? 'not chosen', 'version' => $i['app_version'] ?? '?',
            'android' => insights_android($i['android'] === null ? null : (int)$i['android']),
        ] as $k => $v) {
            $by[$k][$v] ??= $blank();
            $add($by[$k][$v], $i);
        }
    }
    krsort($byDay);
    foreach ($by as &$groups) {
        uasort($groups, fn ($a, $b) => $b['installs'] <=> $a['installs']);
    }
    unset($groups);

    $funnel = [];
    foreach (INSIGHTS_FUNNEL as $name) {
        $reached = array_filter($fresh, fn ($i) => isset($i['steps'][$name]));
        $times = array_values(array_filter(array_map(fn ($i) => $i['steps'][$name], $reached), fn ($t) => $t >= 0));
        $funnel[$name] = ['reached' => count($reached), 'median_secs' => insights_median($times)];
    }
    $features = [];
    foreach (INSIGHTS_FEATURES as $name) {
        $features[$name] = count(array_filter($fresh, fn ($i) => isset($i['steps'][$name])));
    }
    arsort($features);

    // The newest new shops that have not made a bill yet: where each one stopped.
    $short = function (array $i) use ($now): array {
        $s = $i['steps'] ?? [];
        asort($s);
        return [
            'ref' => insights_ref($i['install_id']),
            'first_seen_h' => round(($now - strtotime((string)$i['first_seen'])) / 3600, 1),
            'last_seen_h' => round(($now - strtotime((string)$i['last_seen'])) / 3600, 1),
            'days_seen' => (int)$i['days_seen'],
            'version' => $i['app_version'],
            'android' => $i['android'] === null ? null : (int)$i['android'],
            'lang' => $i['lang'],
            'kind' => $i['kind'],
            'products' => (int)$i['products'],
            'bills_7d' => (int)$i['bills_7d'],
            'steps' => $s,
        ];
    };
    $notSelling = array_slice(array_values(array_filter($fresh, fn ($i) => !isset($i['steps']['bill']))), 0, 40);
    $selling = array_slice(array_values(array_filter($fresh, fn ($i) => isset($i['steps']['bill']))), 0, 30);
    // Before steps: the newest that never chose their kind of shop (stopped on the first screens, or still there).
    $noSetup = array_slice(array_values(array_filter($installs, fn ($i) => $i['kind'] === null)), 0, 30);

    return [
        'generated_at' => date('Y-m-d H:i:s', $now),
        'timezone' => date_default_timezone_get(),
        'days' => $days,
        'active' => $active,
        'checkins' => $checkins,
        'by_day' => $byDay,
        'by' => $by,
        'steps_installs' => count($fresh),
        'funnel' => $funnel,
        'features' => $features,
        'not_selling' => array_map($short, $notSelling),
        'selling' => array_map($short, $selling),
        'no_setup' => array_map($short, $noSetup),
    ];
}

/** The report as text, for reading. */
function insights_text(array $r): string
{
    $a = $r['active'];
    $c = $r['checkins'];
    $n = $c['installs'];
    $out = [];
    $out[] = "Tillo Mobile insights, {$r['generated_at']} ({$r['timezone']})";
    $out[] = "Active: today {$a['today']}, 7 days {$a['days_7']}, 30 days {$a['days_30']}. Selling in 7 days {$a['selling_7d']} (10+ bills: {$a['regular_7d']}). New: today {$a['new_today']}, 7 days {$a['new_7d']}.";
    $out[] = '';
    $out[] = "Installations first seen in the last {$r['days']} days: $n";
    $out[] = 'From check-ins (all versions): chose kind of shop ' . insights_pct($c['set_up'], $n) . ', named it ' . insights_pct($c['named'], $n)
        . ', own products (more than the 3 samples) ' . insights_pct($c['own_products'], $n) . ', made a sale ' . insights_pct($c['sold'], $n)
        . ', came back another day ' . insights_pct($c['came_back'], $n) . ', selling in the last 7 days ' . insights_pct($c['selling_7d'], $n) . '.';
    $out[] = '';
    $out[] = 'By day first seen: installs | kind chosen | own products | sold | came back | selling 7d | with steps: ' . implode(' > ', INSIGHTS_FUNNEL);
    foreach ($r['by_day'] as $day => $d) {
        $line = sprintf('  %s  %4d | %4s | %4s | %4s | %4s | %4s', $day, $d['installs'], insights_pct($d['set_up'], $d['installs']),
            insights_pct($d['own_products'], $d['installs']), insights_pct($d['sold'], $d['installs']),
            insights_pct($d['came_back'], $d['installs']), insights_pct($d['selling_7d'], $d['installs']));
        if ($d['with_steps'] > 0) {
            $line .= ' | ' . $d['with_steps'] . ': ' . implode(' > ', array_map(fn ($s) => $d['steps'][$s], INSIGHTS_FUNNEL));
        }
        $out[] = $line;
    }
    foreach (['lang' => 'language', 'kind' => 'kind of shop', 'version' => 'app version', 'android' => 'Android'] as $k => $label) {
        $out[] = '';
        $out[] = "By $label: installs | kind chosen | sold | came back | selling 7d";
        foreach (array_slice($r['by'][$k], 0, 12, true) as $v => $g) {
            $out[] = sprintf('  %-14s %4d | %4s | %4s | %4s | %4s', $v, $g['installs'], insights_pct($g['set_up'], $g['installs']),
                insights_pct($g['sold'], $g['installs']), insights_pct($g['came_back'], $g['installs']), insights_pct($g['selling_7d'], $g['installs']));
        }
    }
    $f = $r['steps_installs'];
    $out[] = '';
    $out[] = "Steps (Tillo Mobile 0.9.9 on; new shops, not restored or second phones): $f installations";
    if ($f > 0) {
        foreach ($r['funnel'] as $name => $s) {
            $out[] = sprintf('  %-8s %4d  %4s   median %s after installing', $name, $s['reached'], insights_pct($s['reached'], $f), insights_took($s['median_secs']));
        }
        $out[] = '  Tried: ' . implode(', ', array_map(fn ($k, $v) => "$k $v", array_keys($r['features']), $r['features']));
        $show = function (array $i): string {
            $steps = implode(' ', array_map(fn ($k, $v) => $k . '@' . insights_took($v), array_keys($i['steps']), $i['steps']));
            return sprintf('  %s  %5.1fh ago, last %5.1fh ago, %d day(s), %s, Android %s, %s, %s, %d products | %s', $i['ref'], $i['first_seen_h'],
                $i['last_seen_h'], $i['days_seen'], $i['version'] ?? '?', $i['android'] ?? '?', $i['lang'] ?? '?', $i['kind'] ?? 'no kind', $i['products'], $steps);
        };
        $out[] = '';
        $out[] = 'Newest that have not made a bill yet (steps @ time after installing):';
        foreach ($r['not_selling'] as $i) {
            $out[] = $show($i);
        }
        $out[] = '';
        $out[] = 'Newest that made a bill:';
        foreach ($r['selling'] as $i) {
            $out[] = $show($i);
        }
    }
    $out[] = '';
    $out[] = 'Newest that never chose a kind of shop (from check-ins):';
    foreach ($r['no_setup'] as $i) {
        $out[] = sprintf('  %s  %5.1fh ago, last %5.1fh ago, %d day(s), %s, Android %s, %s', $i['ref'], $i['first_seen_h'], $i['last_seen_h'],
            $i['days_seen'], $i['version'] ?? '?', $i['android'] ?? '?', $i['lang'] ?? '?');
    }
    return implode("\n", $out) . "\n";
}

/** Writes [$text] to [$file] whole (a reader never sees half of it). */
function insights_write(string $file, string $text): void
{
    $temp = $file . '.tmp';
    if (file_put_contents($temp, $text, LOCK_EX) !== false) {
        rename($temp, $file);
    }
}

/**
 * Writes the report to insights/ when the last one is older than INSIGHTS_EVERY ([$force]: now). One request at a time;
 * never fails the request that asked.
 */
function insights_snapshot(bool $force = false): void
{
    try {
        $dir = INSIGHTS_DIR;
        $txt = $dir . '/latest.txt';
        if (!$force && is_file($txt) && filemtime($txt) > time() - INSIGHTS_EVERY) {
            return;
        }
        if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
            return;
        }
        // Never served, even without the site's own rule (.htaccess at the top).
        if (!is_file($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        }
        $lock = @fopen($dir . '/write.lock', 'c');
        if ($lock === false) {
            return;
        }
        try {
            if (!flock($lock, LOCK_EX | LOCK_NB)) {
                return;
            }
            $r = insights_report(14);
            insights_write($dir . '/latest.json', (string)json_encode($r, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            insights_write($txt, insights_text($r));
            flock($lock, LOCK_UN);
        } finally {
            fclose($lock);
        }
    } catch (Throwable) {
        // Written again after a later check-in.
    }
}
