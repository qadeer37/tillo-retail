<?php
// /delete: a shop owner deletes the shop's online account on Tillo Cloud, with everything it sent (Google Play asks for
// a web page like this, and for the same in the app: Tillo Mobile > More > Online reports). Sign in with the mobile
// number and password; every shop on that number with that password is deleted at once.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

$error = null;
$deleted = null;
$phone = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    check_csrf();
    $phone = (string)($_POST['phone'] ?? '');
    if (empty($_POST['confirm'])) {
        $error = 'Tick the box to confirm that everything is deleted for good.';
    } else {
        $stores = stores_for_sign_in($phone, (string)($_POST['password'] ?? ''));
        if (is_string($stores)) {
            $error = $stores;
        } else {
            foreach ($stores as $store) {
                delete_store((int)$store['id']);
            }
            $deleted = array_map(fn ($s) => (string)$s['name'], $stores);
            $phone = '';
            // A signed-in owner of a deleted shop has nothing left to see.
            sign_out();
        }
    }
}

page_start('Delete your account', ['body' => 'page-login']);
?>
<section class="login delete-account">
    <h1>Delete your Tillo account</h1>
    <p class="lead">For <strong>Tillo – Mobile POS</strong> and <strong>Tillo Retail</strong> (developer: Tillo Retail).
        This deletes your shop's online-reports account at my.tillopro.com and everything your shop sent to it.</p>

    <?php if ($deleted !== null): ?>
        <div class="alert ok">Deleted: <?= h(implode(', ', $deleted)) ?>. The account, its sales and its deliveries are gone from Tillo Cloud.
            To stop the app sending again, turn off online reports in it (or uninstall it).</div>
    <?php endif ?>
    <?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif ?>

    <h2>How to delete it</h2>
    <ol class="steps">
        <li><strong>In the app:</strong> Tillo Mobile › More › Online reports › <strong>Delete my online account</strong>.</li>
        <li><strong>Or here:</strong> type the shop's mobile number and online-reports password below, tick the box and press
            <strong>Delete my account</strong>. It is deleted at once.</li>
        <li><strong>Forgot the password?</strong> Send your shop's name and mobile number on WhatsApp to
            <a href="https://wa.me/923123245056">0312-3245056</a>. Tillo deletes the account within 7 days, after checking the number is yours.</li>
    </ol>

    <form method="post" class="card form" autocomplete="on">
        <?= csrf_field() ?>
        <label for="phone">Mobile number</label>
        <input id="phone" name="phone" type="tel" inputmode="tel" autocomplete="username" placeholder="0300-1234567" required value="<?= h($phone) ?>">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <label class="check"><input type="checkbox" name="confirm" value="1"> I understand that my shop's online account and everything below is deleted for good.</label>
        <button class="btn btn-danger" type="submit">Delete my account</button>
    </form>

    <h2>What is deleted</h2>
    <ul>
        <li>The online account: the shop's name, city, mobile number and password.</li>
        <li>Every sale, return, cancelled bill and delivery the shop sent, with customer names on bills.</li>
    </ul>
    <p>None of this is kept: it is removed from Tillo Cloud straight away.</p>

    <h2>What is kept</h2>
    <ul>
        <li><strong>The license record</strong>, if the shop bought a license key: the shop's name, mobile number, the
            phone's or computer's code and the key. Tillo keeps it so a paid license can be given again on a new phone.
            To have it removed too, ask on WhatsApp.</li>
        <li><strong>Data on your phone and your Google Drive backup</strong> never reach Tillo's servers, so they are not
            touched. Uninstalling the app removes the phone's data; the backup is removed in Google Drive › Settings ›
            Manage apps › Tillo › Delete hidden app data.</li>
    </ul>
    <p class="urdu-note" lang="ur" dir="rtl">اکاؤنٹ ختم کرنے کے لیے دکان کا موبائل نمبر اور پاس ورڈ لکھیں، باکس پر نشان لگائیں اور «Delete my account» دبائیں۔ پاس ورڈ یاد نہیں تو واٹس ایپ 0312-3245056 پر رابطہ کریں۔</p>
</section>
<?php
page_end();
