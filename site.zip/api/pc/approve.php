<?php
// POST /api/pc/approve: the main phone lets a computer join. Authorization: Bearer <phone A's token>.
// {"pair": "<32 hex or the link>", "code": "<the join code from /api/phones/invite>", "name": "Counter computer"}
// The join code must be this shop's, not used and not run out. Answers {"ok"}; the computer then takes the code.

declare(strict_types=1);

require __DIR__ . '/../../lib/pc.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
if ($phone['letter'] !== 'A') {
    json_error(403, 'Only the main phone can connect a computer.');
}
$data = read_json();
$pair = pc_pair($data['pair'] ?? null);
if (!$pair || (int)$pair['expires_at'] < time()) {
    json_error(404, 'This code on the computer has changed. Scan the new one.');
}
if ($pair['approved_at'] !== null) {
    json_error(409, 'This computer was connected already.');
}
$code = strtolower(trim((string)($data['code'] ?? '')));
if (str_starts_with($code, 'tillo-join:')) {
    $code = substr($code, 11);
}
$join = preg_match('/^[0-9a-f]{32}$/', $code)
    ? q('SELECT * FROM phone_joins WHERE code_hash = ? AND store_id = ?', [hash('sha256', $code), $storeId])->fetch()
    : false;
if (!$join || $join['used_at'] !== null || (int)$join['expires_at'] < time()) {
    json_error(404, 'The shop\'s copy for the computer ran out. Try again.');
}
// Taken only once, and only while the join code still works.
$done = q('UPDATE pc_pairs SET store_id = ?, join_code = ?, name = ?, approved_at = ?, expires_at = ? WHERE pair_hash = ? AND approved_at IS NULL',
    [$storeId, $code, clip($data['name'] ?? null, 60) ?? 'Computer', time(), (int)$join['expires_at'], $pair['pair_hash']])->rowCount();
if ($done !== 1) {
    json_error(409, 'This computer was connected already.');
}
json_out(200, ['ok' => true]);
