<?php
// POST /api/phones/remove: {"letter": "C"}. Authorization: Bearer <phone token>. The main phone removes any other
// phone (or all of them, with no letter or "A"); any other phone can only leave itself. A removed phone hears so on
// its next /api/phones/sync (410). When only the main phone is left, the shop is back to one phone: everything its
// phones had here is deleted. Answers {"ok", "alone": bool}.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$data = read_json();
$storeId = (int)$phone['store_id'];
$letter = strtoupper(trim((string)($data['letter'] ?? '')));
if ($phone['letter'] !== 'A') {
    $letter = $phone['letter'];
}
if ($letter === '' || $letter === 'A') {
    phones_forget_store($storeId);
    json_out(200, ['ok' => true, 'alone' => true]);
}
q('DELETE FROM phone_links WHERE store_id = ? AND letter = ?', [$storeId, $letter]);
if (other_phones($storeId, 'A') === [] && waiting_join($storeId) === null) {
    phones_forget_store($storeId);
    json_out(200, ['ok' => true, 'alone' => true]);
}
delete_delivered($storeId);
json_out(200, ['ok' => true, 'alone' => false]);
