<?php
// POST /api/pc/look: the main phone scanned a computer's QR and asks what it is, to show before connecting.
// {"pair": "<32 hex or the link>"}. Answers {"ok", "device" ("Chrome on Windows"), "expires_in"}.

declare(strict_types=1);

require __DIR__ . '/../../lib/pc.php';

$data = read_json();
$keys = ['pc-look:' . client_ip()];
if (throttled($keys)) {
    json_error(429, 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.');
}
$pair = pc_pair($data['pair'] ?? null);
if (!$pair || (int)$pair['expires_at'] < time() || $pair['approved_at'] !== null) {
    record_failure($keys);
    json_error(404, 'This code on the computer has changed. Scan the new one.');
}
json_out(200, ['ok' => true, 'device' => $pair['device'], 'expires_in' => max(0, (int)$pair['expires_at'] - time())]);
