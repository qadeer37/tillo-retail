<?php
// Up to 5 phones, one shop (Tillo Mobile, More > Phones). The main phone (A) shows a QR code; a new phone scans it,
// downloads a copy of the shop once, takes the next free letter (B to E), and from then on the phones send each other
// their changes through here. Nothing is kept longer than it takes to reach every other phone: a change goes once all
// of them have it, the copy of the shop once the new phone has downloaded it, a photo once every other phone has it. A
// shop with one phone has nothing here at all.
//
// Every phone proves itself with its own token (Authorization: Bearer <64 hex>); only the sha256 is kept.

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

/** Phones a shop may have: the main phone (A) and up to four more (B to E). */
const MAX_PHONES = 5;
const PHONE_LETTERS = ['A', 'B', 'C', 'D', 'E'];
/** How long a join code works. */
const JOIN_SECONDS = 600;
/** A second phone not seen for this long is let go: nothing more is kept for it. */
const PHONE_GONE_SECONDS = 30 * 86400;
/** Changes in one request, each way. */
const MAX_CHANGES = 500;
/** Largest copy of a shop, and largest photo. */
const MAX_SNAPSHOT_BYTES = 40 * 1024 * 1024;
const MAX_PHOTO_BYTES = 1024 * 1024;

/** The folder for copies of shops and photos on their way: next to the settings file, never in the public folder. */
function phone_files_dir(): string
{
    $dir = dirname(config_path()) . '/tillo-phone-files';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    return $dir;
}

function snapshot_file(int $storeId, string $codeHash): string
{
    return phone_files_dir() . '/shop-' . $storeId . '-' . substr($codeHash, 0, 32) . '.bin';
}

/** A product photo's name as the app makes them (letters, digits, dot, dash, underscore), or null. */
function photo_name(mixed $name): ?string
{
    return is_string($name) && preg_match('/^[A-Za-z0-9._-]{1,80}$/', $name) && !str_starts_with($name, '.') ? $name : null;
}

function photo_file(int $storeId, string $name): string
{
    return phone_files_dir() . '/photo-' . $storeId . '-' . $name;
}

/** The phone whose token came with the request (and its shop), or an error answer. A removed phone is told so (410). */
function api_phone(): array
{
    $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (!preg_match('/^Bearer\s+([0-9a-f]{64})$/i', trim($header), $m)) {
        json_error(401, 'This phone is not joined to a shop.');
    }
    $phone = q('SELECT * FROM phone_links WHERE token_hash = ?', [hash('sha256', strtolower($m[1]))])->fetch();
    if (!$phone) {
        json_out(410, ['ok' => false, 'removed' => true, 'error' => 'This phone was removed from the shop. Scan a new code on the main phone to join again.']);
    }
    if ((int)$phone['expired'] === 1) {
        json_out(410, ['ok' => false, 'removed' => true, 'error' => 'This phone was not used for 30 days, so it left the shop. Scan a new code on the main phone to join again.']);
    }
    q('UPDATE phone_links SET last_seen_at = ? WHERE id = ?', [time(), $phone['id']]);
    $phone['last_seen_at'] = time();
    return $phone;
}

/** The shop's phones, for the Phones screen: [{letter, name, last_seen (seconds ago), expired}]. */
function phone_list(int $storeId): array
{
    $now = time();
    $list = [];
    foreach (q('SELECT letter, name, last_seen_at, expired FROM phone_links WHERE store_id = ? ORDER BY letter', [$storeId])->fetchAll() as $row) {
        $list[] = [
            'letter' => $row['letter'],
            'name' => $row['name'],
            'last_seen' => max(0, $now - (int)$row['last_seen_at']),
            'expired' => (int)$row['expired'] === 1,
        ];
    }
    return $list;
}

/** The shop's phones still joined (not let go after 30 days), by letter. */
function active_phones(int $storeId): array
{
    $phones = [];
    foreach (q('SELECT * FROM phone_links WHERE store_id = ? AND expired = 0 ORDER BY letter', [$storeId])->fetchAll() as $row) {
        $phones[$row['letter']] = $row;
    }
    return $phones;
}

/** The join code the main phone is showing now (not used, not run out), or null. */
function waiting_join(int $storeId): ?array
{
    $row = q('SELECT * FROM phone_joins WHERE store_id = ? AND used_at IS NULL AND expires_at >= ?', [$storeId, time()])->fetch();
    return $row ?: null;
}

/** Lets a phone go when it hasn't been seen for 30 days (never the main phone): nothing more is kept for it. */
function expire_quiet_phones(int $storeId): void
{
    $quiet = q("SELECT id FROM phone_links WHERE store_id = ? AND letter <> 'A' AND expired = 0 AND last_seen_at < ?",
        [$storeId, time() - PHONE_GONE_SECONDS])->fetchAll();
    foreach ($quiet as $row) {
        q('UPDATE phone_links SET expired = 1 WHERE id = ?', [$row['id']]);
    }
    if ($quiet) {
        delete_delivered($storeId);
    }
}

/**
 * Deletes the changes every phone that needs them has: a change from one phone goes once each other joined phone's
 * "after" has passed it, and, while a join code is shown, once it is in the copy of the shop the new phone gets.
 */
function delete_delivered(int $storeId): void
{
    $phones = active_phones($storeId);
    $join = waiting_join($storeId);
    foreach (q('SELECT DISTINCT from_letter FROM phone_changes WHERE store_id = ?', [$storeId])->fetchAll(PDO::FETCH_COLUMN) as $from) {
        $others = array_filter($phones, fn($p) => $p['letter'] !== $from);
        $upTo = $others ? min(array_map(fn($p) => (int)$p['acked_seq'], $others)) : PHP_INT_MAX;
        if ($join !== null) {
            $upTo = min($upTo, (int)$join['snapshot_seq']);
        }
        q('DELETE FROM phone_changes WHERE store_id = ? AND from_letter = ? AND seq <= ?', [$storeId, $from, $upTo]);
    }
}

/** The other joined phones of a shop (not [letter]). */
function other_phones(int $storeId, string $letter): array
{
    return array_values(array_filter(active_phones($storeId), fn($p) => $p['letter'] !== $letter));
}

/** Deletes join codes that ran out or were used, with their copies of the shop. */
function delete_old_joins(int $storeId, bool $all = false): void
{
    $rows = $all
        ? q('SELECT code_hash FROM phone_joins WHERE store_id = ?', [$storeId])->fetchAll()
        : q('SELECT code_hash FROM phone_joins WHERE store_id = ? AND ((expires_at < ? AND used_at IS NULL) OR used_at < ?)', [$storeId, time(), time() - 3600])->fetchAll();
    foreach ($rows as $row) {
        @unlink(snapshot_file($storeId, $row['code_hash']));
        q('DELETE FROM phone_joins WHERE code_hash = ?', [$row['code_hash']]);
    }
}

function delete_photos(int $storeId): void
{
    foreach (glob(phone_files_dir() . '/photo-' . $storeId . '-*') ?: [] as $file) {
        @unlink($file);
    }
    @unlink(wants_file($storeId));
}

/** Who sent a photo and which phones have fetched it: kept next to the photo. */
function photo_info(int $storeId, string $name): array
{
    $info = json_decode((string)@file_get_contents(photo_file($storeId, $name) . '.json'), true);
    return is_array($info) ? $info + ['from' => '', 'got' => []] : ['from' => '', 'got' => []];
}

function save_photo_info(int $storeId, string $name, array $info): void
{
    file_put_contents(photo_file($storeId, $name) . '.json', json_encode($info), LOCK_EX);
}

/** Deletes a photo once every joined phone besides its sender has it (and no new phone is about to join). */
function delete_photo_if_done(int $storeId, string $name): void
{
    if (waiting_join($storeId) !== null) {
        return;
    }
    $info = photo_info($storeId, $name);
    foreach (active_phones($storeId) as $letter => $phone) {
        if ($letter !== $info['from'] && !in_array($letter, $info['got'], true)) {
            return;
        }
    }
    @unlink(photo_file($storeId, $name));
    @unlink(photo_file($storeId, $name) . '.json');
}

/** Photos a phone asked for that no phone has sent yet (a new phone needs the photos of the shop it took). */
function wants_file(int $storeId): string
{
    return phone_files_dir() . '/wants-' . $storeId . '.json';
}

function photo_wants(int $storeId): array
{
    $wants = json_decode((string)@file_get_contents(wants_file($storeId)), true);
    return is_array($wants) ? array_values(array_filter($wants, fn($n) => photo_name($n) !== null)) : [];
}

function save_photo_wants(int $storeId, array $wants): void
{
    $wants = array_slice(array_values(array_unique($wants)), 0, 500);
    if ($wants) {
        file_put_contents(wants_file($storeId), json_encode($wants), LOCK_EX);
    } else {
        @unlink(wants_file($storeId));
    }
}

/** Everything a shop's phones had here: back to one phone, as if it never had two. */
function phones_forget_store(int $storeId): void
{
    delete_old_joins($storeId, true);
    delete_photos($storeId);
    q('DELETE FROM phone_changes WHERE store_id = ?', [$storeId]);
    q('DELETE FROM phone_links WHERE store_id = ?', [$storeId]);
}

/** The raw body of a POST (a copy of the shop, a photo), or an error answer when it is missing or too big. */
function read_bytes(int $max): string
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_error(405, 'Use POST.');
    }
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > $max) {
        json_error(413, 'Too big.');
    }
    $bytes = file_get_contents('php://input', false, null, 0, $max + 1);
    if ($bytes === false || $bytes === '') {
        json_error(400, 'Nothing was sent.');
    }
    if (strlen($bytes) > $max) {
        json_error(413, 'Too big.');
    }
    return $bytes;
}

/** Sends a file as the answer, then stops. */
function send_file(string $file): never
{
    header('Content-Type: application/octet-stream');
    header('Cache-Control: no-store');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
