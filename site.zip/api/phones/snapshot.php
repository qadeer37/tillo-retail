<?php
// POST /api/phones/snapshot: the joined phone downloads the copy of the shop (the bytes the main phone sent).
// Authorization: Bearer <phone B's token>. It can be fetched again until the phone's first /api/phones/sync, which
// tells the server the copy is in, and it is deleted.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
$join = q('SELECT code_hash FROM phone_joins WHERE store_id = ? AND used_at IS NOT NULL ORDER BY used_at DESC', [$storeId])->fetch();
$file = $join ? snapshot_file($storeId, $join['code_hash']) : '';
if ($phone['letter'] === 'A' || !$join || !is_file($file)) {
    json_error(404, 'The copy of the shop is not here any more. Scan a new code on the main phone.');
}
send_file($file);
