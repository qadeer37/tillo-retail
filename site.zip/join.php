<?php
// /join/<code>: the main phone's QR (Phones › Add a phone), opened by Google Lens or the camera on the new phone. With
// Tillo installed, Android opens Tillo itself (the app link); here, in the browser, a button opens Tillo with the code
// (or Play Store, where Tillo isn't installed yet). Nothing is read or changed here: Tillo does the joining.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

$code = strtolower((string)($_GET['c'] ?? ''));
$ok = preg_match('/^[0-9a-f]{32}$/', $code) === 1;
$play = 'https://play.google.com/store/apps/details?id=com.tilloretail.mobile&referrer=utm_source%3Djoin_link';
// Chrome on Android: open Tillo with this link, or Play Store when it isn't installed.
$open = 'intent://my.tillopro.com/join/' . $code . '#Intent;scheme=https;package=com.tilloretail.mobile;S.browser_fallback_url='
    . rawurlencode($play) . ';end';

page_start('Join a shop', ['body' => 'page-join']);
?>
<section class="card" style="text-align:center;padding:28px 20px">
<?php if ($ok): ?>
    <h1>Join this shop on Tillo</h1>
    <p>This code is from the shop's main phone (More › Phones › Add a phone). It works for 10 minutes.</p>
    <p><a class="btn" href="<?= h($open) ?>">Open in Tillo</a></p>
    <p class="muted small">Tillo not on this phone yet? Install it, open it, then scan the code again.</p>
    <p><a class="btn btn-small" href="<?= h($play) ?>">Get Tillo on Google Play</a></p>
    <p class="muted small" lang="ur" dir="rtl">یہ کوڈ دکان کے مین فون سے ہے۔ Tillo میں کھولیں۔ اگر Tillo نہیں ہے تو پہلے انسٹال کریں، کھولیں، پھر کوڈ دوبارہ اسکین کریں۔</p>
<?php else: ?>
    <h1>This isn't a Tillo code</h1>
    <p>On the shop's main phone, open Tillo › More › Phones › Add a phone, and scan the new code.</p>
<?php endif ?>
</section>
<?php
page_end();
