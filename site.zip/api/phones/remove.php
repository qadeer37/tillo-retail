<?php
// POST /api/phones/remove: the main phone removes the second phone, or the second phone leaves. Authorization: Bearer
// <phone token>. Either way the shop is back to one phone: everything its phones had here is deleted, and the other
// phone hears so on its next /api/phones/sync (410).

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
read_json();
phones_forget_store((int)$phone['store_id']);
json_out(200, ['ok' => true]);
