<?php
// The owner's sign-in: the shop's mobile number and the password set in Tillo Retail (Settings > Online reports).

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

if (owner_stores()) {
    header('Location: /reports');
    exit;
}

$error = null;
$phone = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    check_csrf();
    $phone = (string)($_POST['phone'] ?? '');
    $error = owner_sign_in($phone, (string)($_POST['password'] ?? ''));
    if ($error === null) {
        header('Location: /reports');
        exit;
    }
}

page_start('Sign in', ['body' => 'page-login']);
?>
<section class="login">
    <h1>Your shop's sales, anywhere</h1>
    <p class="lead">Sign in with the mobile number and password you set in Tillo Retail.</p>
    <?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif ?>
    <form method="post" class="card form" autocomplete="on">
        <?= csrf_field() ?>
        <label for="phone">Mobile number</label>
        <input id="phone" name="phone" type="tel" inputmode="tel" autocomplete="username" placeholder="0300-1234567" required value="<?= h($phone) ?>">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <button class="btn" type="submit">Sign in</button>
    </form>
    <div class="help">
        <h2>No password yet?</h2>
        <p>In Tillo Retail, open <strong>Settings &gt; Online reports</strong>, turn it on and choose a password. Your sales then show here within a minute.</p>
        <h2>Forgot it?</h2>
        <p>Set a new one in the same place in Tillo Retail, or ask Tillo support on WhatsApp <a href="https://wa.me/923123245056">0312-3245056</a>.</p>
    </div>
    <p class="urdu-note" lang="ur" dir="rtl">ٹلو ریٹیل میں سیٹنگز ‹ آن لائن رپورٹس میں موبائل نمبر اور پاس ورڈ رکھیں، پھر یہاں سائن ان کریں۔</p>
</section>
<?php
page_end();
