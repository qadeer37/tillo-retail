<?php
// One-time setup: POST /setup with JSON
//   {"secret": "...", "db": {"name": "...", "user": "...", "pass": "..."}, "support_password": "..."}
// The secret's sha256 must match TILLO_SETUP_HASH. Checks the database, creates the tables and writes the settings file
// outside the public folder. Once that file exists this page does nothing (answers 410), so it can stay deployed.

declare(strict_types=1);

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/schema.php';

if (config() !== null) {
    json_error(410, 'Already set up.');
}
$data = read_json();

$secret = (string)($data['secret'] ?? '');
if ($secret === '' || !hash_equals(TILLO_SETUP_HASH, hash('sha256', $secret))) {
    sleep(2);
    json_error(403, 'Wrong setup secret.');
}

$db = is_array($data['db'] ?? null) ? $data['db'] : [];
$support = (string)($data['support_password'] ?? '');
if (mb_strlen($support) < 10) {
    json_error(400, 'The support password needs at least 10 characters.');
}

if (isset($db['sqlite'])) {
    $connection = ['dsn' => 'sqlite:' . $db['sqlite']];
} else {
    $name = (string)($db['name'] ?? '');
    $connection = [
        'dsn' => 'mysql:host=' . ($db['host'] ?? 'localhost') . ';dbname=' . $name . ';charset=utf8mb4',
        'user' => (string)($db['user'] ?? ''),
        'pass' => (string)($db['pass'] ?? ''),
    ];
}

try {
    $pdo = connect($connection);
    migrate($pdo);
} catch (Throwable $e) {
    json_error(500, 'Database: ' . $e->getMessage());
}

try {
    write_config([
        'db' => $connection,
        'support_hash' => password_hash($support, PASSWORD_DEFAULT),
        'set_up_at' => now_text(),
    ]);
} catch (Throwable $e) {
    json_error(500, $e->getMessage());
}

$tables = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite'
    ? $pdo->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")->fetchAll(PDO::FETCH_COLUMN)
    : $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
json_out(200, ['ok' => true, 'tables' => $tables, 'config' => basename(config_path())]);
