<?php
// POST /api/register: Tillo Retail links a shop (Settings > Online reports).
//
// {"store_uid": "<the app's StoreId>", "token": "<64 hex, made by the app>", "name": "...", "name_ur": "...",
//  "city": "...", "phone": "0300-1234567", "password": "...", "version": "0.1.14"}
//
// The app makes its own token and keeps it, so sending the same request again (the answer got lost on a bad connection)
// is fine. A shop that is linked already can only be linked again with its token, or after Tillo support unlinked it.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';

$data = read_json();

$uid = strtolower(trim((string)($data['store_uid'] ?? '')));
$token = strtolower(trim((string)($data['token'] ?? '')));
$name = clip($data['name'] ?? null, 120);
$phone = normalize_phone((string)($data['phone'] ?? ''));
$password = (string)($data['password'] ?? '');

if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $uid)) {
    json_error(400, 'The store id is missing.');
}
if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
    json_error(400, 'The link key is missing.');
}
if ($name === null) {
    json_error(400, 'The store name is missing.');
}
if ($phone === '') {
    json_error(400, 'Enter a mobile number, like 0300-1234567.');
}
if ($problem = password_problem($password)) {
    json_error(400, $problem);
}

$tokenHash = hash('sha256', $token);
$fields = [
    'name' => $name,
    'name_ur' => clip($data['name_ur'] ?? null, 120),
    'city' => clip($data['city'] ?? null, 80),
    'phone' => $phone,
    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    'app_version' => clip($data['version'] ?? null, 20),
];

$existing = q('SELECT id, token_hash FROM stores WHERE uid = ?', [$uid])->fetch();
if ($existing) {
    $sameApp = hash_equals((string)$existing['token_hash'], $tokenHash);
    if (!$sameApp && $existing['token_hash'] !== '') {
        json_error(409, 'This shop is already linked to Tillo online reports. To link it again, ask Tillo support on WhatsApp 0312-3245056.');
    }
    q('UPDATE stores SET token_hash = ?, name = ?, name_ur = ?, city = ?, phone = ?, password_hash = ?, app_version = ? WHERE id = ?', [
        $tokenHash, $fields['name'], $fields['name_ur'], $fields['city'], $fields['phone'], $fields['password_hash'], $fields['app_version'],
        $existing['id'],
    ]);
} else {
    q('INSERT INTO stores (uid, token_hash, name, name_ur, city, phone, password_hash, app_version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [
        $uid, $tokenHash, $fields['name'], $fields['name_ur'], $fields['city'], $fields['phone'], $fields['password_hash'], $fields['app_version'],
        now_text(),
    ]);
}

json_out(200, ['ok' => true, 'phone' => show_phone($phone)]);
