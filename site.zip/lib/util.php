<?php
// Small helpers: escaping, numbers, phone numbers, JSON answers.

declare(strict_types=1);

function h(?string $text): string
{
    return htmlspecialchars($text ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Whole rupees, like the app: Rs 1,250. */
function money(float|int|string|null $value): string
{
    $whole = (int)round((float)$value, 0, PHP_ROUND_HALF_UP);
    return 'Rs ' . number_format($whole);
}

/** A number without the rupee sign: 1,250. */
function num(float|int|string|null $value): string
{
    return number_format((int)round((float)$value, 0, PHP_ROUND_HALF_UP));
}

/** A quantity: 2, 2.5, 0.375. */
function qty(float|int|string|null $value): string
{
    $text = number_format((float)$value, 3, '.', ',');
    return rtrim(rtrim($text, '0'), '.');
}

/**
 * A Pakistani mobile number in one form, 923001234567, whatever way it was typed (0300-1234567, +92 300 1234567,
 * 3001234567). Other numbers keep their digits. Empty when it can't be a phone number.
 */
function normalize_phone(?string $text): string
{
    $digits = preg_replace('/\D+/', '', $text ?? '') ?? '';
    if (str_starts_with($digits, '0092')) {
        $digits = substr($digits, 2);
    }
    if (strlen($digits) === 11 && str_starts_with($digits, '03')) {
        $digits = '92' . substr($digits, 1);
    } elseif (strlen($digits) === 10 && str_starts_with($digits, '3')) {
        $digits = '92' . $digits;
    }
    return strlen($digits) >= 10 && strlen($digits) <= 15 ? $digits : '';
}

/** 923001234567 as 0300-1234567. */
function show_phone(string $phone): string
{
    if (strlen($phone) === 12 && str_starts_with($phone, '923')) {
        return '0' . substr($phone, 2, 3) . '-' . substr($phone, 5);
    }
    return '+' . $phone;
}

/** Text cut to a column's length (null stays null). */
function clip(mixed $value, int $length): ?string
{
    if ($value === null) {
        return null;
    }
    $text = trim((string)$value);
    return $text === '' ? null : mb_substr($text, 0, $length);
}

function dec(mixed $value): float
{
    return is_numeric($value) ? round((float)$value, 3) : 0.0;
}

/** A yyyy-mm-dd date, or null. */
function valid_date(mixed $value): ?string
{
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return null;
    }
    [$y, $m, $d] = array_map('intval', explode('-', $value));
    return checkdate($m, $d, $y) ? $value : null;
}

/** A yyyy-mm-dd hh:mm:ss time, or null. */
function valid_time(mixed $value): ?string
{
    if (!is_string($value) || !preg_match('/^(\d{4}-\d{2}-\d{2}) (\d{2}):(\d{2}):(\d{2})$/', $value, $m)) {
        return null;
    }
    return valid_date($m[1]) !== null && (int)$m[2] < 24 && (int)$m[3] < 60 && (int)$m[4] < 60 ? $value : null;
}

function json_out(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(int $status, string $message): never
{
    json_out($status, ['ok' => false, 'error' => $message]);
}

/** The JSON body of a POST request, or an error answer. */
function read_json(): array
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_error(405, 'Use POST.');
    }
    $body = file_get_contents('php://input');
    $data = json_decode($body === false ? '' : $body, true);
    if (!is_array($data)) {
        json_error(400, 'The request is not valid JSON.');
    }
    return $data;
}

function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

/** A random secret, as hex. */
function token(int $bytes = 32): string
{
    return bin2hex(random_bytes($bytes));
}
