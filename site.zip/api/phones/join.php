<?php
// POST /api/phones/join: a new phone scanned the main phone's QR. {"code": "<32 hex>", "name": "Counter 2"}
// Answers {"ok", "phone_token" (64 hex, kept by the app), "letter" (the next free of B to E), "shop": {"name",
// "name_ur", "city"}, "main": "<the main phone's name>", "after", "snapshot_bytes"}; then the phone downloads the
// copy of the shop (/api/phones/snapshot).

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$data = read_json();
$code = strtolower(trim((string)($data['code'] ?? '')));
if (str_starts_with($code, 'tillo-join:')) {
    $code = substr($code, 11);
}
$keys = ['join:' . client_ip()];
if (throttled($keys)) {
    json_error(429, 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.');
}
$join = preg_match('/^[0-9a-f]{32}$/', $code)
    ? q('SELECT * FROM phone_joins WHERE code_hash = ?', [hash('sha256', $code)])->fetch()
    : false;
if (!$join || $join['used_at'] !== null || (int)$join['expires_at'] < time()) {
    record_failure($keys);
    json_error(404, 'This code has run out or was used already. Show a new one on the main phone.');
}
$storeId = (int)$join['store_id'];
$store = q('SELECT name, name_ur, city FROM stores WHERE id = ?', [$storeId])->fetch();
$main = q("SELECT name FROM phone_links WHERE store_id = ? AND letter = 'A'", [$storeId])->fetch();
if (!$store || !$main) {
    json_error(404, 'This shop is not ready for another phone. Show a new code on the main phone.');
}
expire_quiet_phones($storeId);
$taken = array_keys(active_phones($storeId));
if (count($taken) >= MAX_PHONES) {
    json_error(409, 'This shop has ' . MAX_PHONES . ' phones already. Remove one on the main phone first.');
}
$letter = array_values(array_diff(PHONE_LETTERS, $taken))[0];

$token = token();
$pdo = db();
$pdo->beginTransaction();
try {
    // A phone let go after 30 days leaves its letter free.
    q('DELETE FROM phone_links WHERE store_id = ? AND letter = ?', [$storeId, $letter]);
    q('INSERT INTO phone_links (store_id, letter, name, token_hash, acked_seq, expired, joined_at, last_seen_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)',
        [$storeId, $letter, clip($data['name'] ?? null, 60) ?? 'Phone ' . $letter, hash('sha256', $token), (int)$join['snapshot_seq'], now_text(), time()]);
    q('UPDATE phone_joins SET used_at = ? WHERE code_hash = ?', [time(), $join['code_hash']]);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
}

json_out(200, [
    'ok' => true,
    'phone_token' => $token,
    'letter' => $letter,
    'shop' => ['name' => $store['name'], 'name_ur' => $store['name_ur'], 'city' => $store['city']],
    'main' => $main['name'],
    'after' => (int)$join['snapshot_seq'],
    'snapshot_bytes' => (int)$join['snapshot_bytes'],
]);
