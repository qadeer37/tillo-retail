<?php
declare(strict_types=1);

require __DIR__ . '/lib/auth.php';

sign_out();
header('Location: /login');
