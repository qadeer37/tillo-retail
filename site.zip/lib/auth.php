<?php
// Who is asking: shop owners (phone + password, a browser session), Tillo support (the support password) and Tillo Retail
// itself (the shop's token, on the API).

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/** Sign-in tries allowed per phone (and per address) in THROTTLE_MINUTES. */
const THROTTLE_TRIES = 10;
const THROTTLE_MINUTES = 15;

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('tillo');
    session_set_cookie_params([
        'lifetime' => 60 * 60 * 24 * 30,
        'path' => '/',
        'secure' => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.gc_maxlifetime', (string)(60 * 60 * 24 * 30));
    session_start();
}

function send_page_headers(): void
{
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('Cache-Control: no-store');
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = token(16);
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function check_csrf(): void
{
    start_session();
    $sent = (string)($_POST['csrf'] ?? '');
    if ($sent === '' || !hash_equals((string)($_SESSION['csrf'] ?? ''), $sent)) {
        http_response_code(400);
        exit('This form has expired. Go back, reload the page and try again.');
    }
}

/** True when there were too many tries for any of the keys lately. */
function throttled(array $keys): bool
{
    $since = time() - THROTTLE_MINUTES * 60;
    foreach ($keys as $key) {
        $count = (int)q('SELECT COUNT(*) FROM login_attempts WHERE k = ? AND at > ?', [$key, $since])->fetchColumn();
        if ($count >= THROTTLE_TRIES) {
            return true;
        }
    }
    return false;
}

function record_failure(array $keys): void
{
    foreach ($keys as $key) {
        q('INSERT INTO login_attempts (k, at) VALUES (?, ?)', [$key, time()]);
    }
    // Old tries are of no use; keep the table small.
    if (random_int(1, 50) === 1) {
        q('DELETE FROM login_attempts WHERE at < ?', [time() - 86400]);
    }
}

// --- Shop owners ---------------------------------------------------------------------------------------------------

/**
 * Signs in with a phone number and password. One phone can own several shops; the owner sees every shop whose
 * password matches. Returns an error message, or null when signed in.
 */
function owner_sign_in(string $phoneText, string $password): ?string
{
    $phone = normalize_phone($phoneText);
    if ($phone === '' || $password === '') {
        return 'Enter your mobile number and password.';
    }
    $keys = ['phone:' . $phone, 'ip:' . client_ip()];
    if (throttled($keys)) {
        return 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.';
    }

    $ids = [];
    foreach (q('SELECT id, password_hash FROM stores WHERE phone = ?', [$phone])->fetchAll() as $store) {
        if (password_verify($password, $store['password_hash'])) {
            $ids[] = (int)$store['id'];
        }
    }
    if (!$ids) {
        record_failure($keys);
        return 'The mobile number or password is not right.';
    }

    start_session();
    session_regenerate_id(true);
    $_SESSION['stores'] = $ids;
    $_SESSION['phone'] = $phone;
    q('UPDATE stores SET last_login_at = ? WHERE id IN (' . implode(',', $ids) . ')', [now_text()]);
    return null;
}

/** The shops the signed-in owner may see (id => row), or an empty array. */
function owner_stores(): array
{
    start_session();
    $ids = array_map('intval', $_SESSION['stores'] ?? []);
    if (!$ids) {
        return [];
    }
    $rows = q('SELECT id, name, name_ur, city, phone, last_sync_at FROM stores WHERE id IN (' . implode(',', $ids) . ') ORDER BY name')->fetchAll();
    $stores = [];
    foreach ($rows as $row) {
        $stores[(int)$row['id']] = $row;
    }
    return $stores;
}

/** The owner's shops; sends a visitor who isn't signed in to the sign-in page. */
function require_owner(): array
{
    $stores = owner_stores();
    if (!$stores) {
        header('Location: /login');
        exit;
    }
    return $stores;
}

function sign_out(): void
{
    start_session();
    $_SESSION = [];
    session_destroy();
}

// --- Tillo support -------------------------------------------------------------------------------------------------

function is_support(): bool
{
    start_session();
    return !empty($_SESSION['support']);
}

function support_sign_in(string $password): ?string
{
    $keys = ['support', 'ip:' . client_ip()];
    if (throttled($keys)) {
        return 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.';
    }
    $hash = (string)(config()['support_hash'] ?? '');
    if ($hash === '' || !password_verify($password, $hash)) {
        record_failure($keys);
        return 'That is not the support password.';
    }
    start_session();
    session_regenerate_id(true);
    $_SESSION['support'] = true;
    return null;
}

// --- Tillo Retail (the API) ----------------------------------------------------------------------------------------

/** The shop whose token came with the request (Authorization: Bearer ...), or an error answer. */
function api_store(): array
{
    $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (!preg_match('/^Bearer\s+([0-9a-f]{64})$/i', trim($header), $m)) {
        json_error(401, 'This shop is not linked. Turn on online reports in Settings.');
    }
    $store = q('SELECT * FROM stores WHERE token_hash = ?', [hash('sha256', strtolower($m[1]))])->fetch();
    if (!$store) {
        json_error(401, 'This shop is not linked any more. Turn on online reports again in Settings.');
    }
    return $store;
}

/** Deletes a shop's online account with everything it sent: sales, returns, cancelled bills and deliveries. */
function delete_store(int $id): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach (['sale_lines', 'sale_payments', 'sales', 'purchase_lines', 'purchases'] as $table) {
            q("DELETE FROM $table WHERE store_id = ?", [$id]);
        }
        q('DELETE FROM stores WHERE id = ?', [$id]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/** The shops on this mobile number whose password matches (an owner may have several), or an error message. */
function stores_for_sign_in(string $phoneText, string $password): array|string
{
    $phone = normalize_phone($phoneText);
    if ($phone === '' || $password === '') {
        return 'Enter your mobile number and password.';
    }
    $keys = ['phone:' . $phone, 'ip:' . client_ip()];
    if (throttled($keys)) {
        return 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.';
    }
    $stores = [];
    foreach (q('SELECT * FROM stores WHERE phone = ?', [$phone])->fetchAll() as $store) {
        if (password_verify($password, $store['password_hash'])) {
            $stores[] = $store;
        }
    }
    if (!$stores) {
        record_failure($keys);
        return 'The mobile number or password is not right.';
    }
    return $stores;
}

/** A password a shop owner may use: at least 4 characters. Returns an error message or null. */
function password_problem(string $password): ?string
{
    if (mb_strlen($password) < 4) {
        return 'The password must be at least 4 characters.';
    }
    if (mb_strlen($password) > 100) {
        return 'The password is too long.';
    }
    return null;
}
