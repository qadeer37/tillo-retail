<?php
// Tillo support: every linked shop, setting a new password for an owner who forgot theirs, and unlinking a shop so it
// can be linked again (a reinstalled computer that restored the shop's backup without its link). Sign in with the
// support password (set during setup; change it below).

declare(strict_types=1);

require __DIR__ . '/lib/view.php';
require __DIR__ . '/lib/schema.php';

$message = null;
$error = null;

if (!is_support()) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        check_csrf();
        $error = support_sign_in((string)($_POST['password'] ?? ''));
        if ($error === null) {
            header('Location: /support');
            exit;
        }
    }
    page_start('Support');
    ?>
    <section class="login">
        <h1>Tillo support</h1>
        <?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif ?>
        <form method="post" class="card form">
            <?= csrf_field() ?>
            <label for="password">Support password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
            <button class="btn" type="submit">Sign in</button>
        </form>
    </section>
    <?php
    page_end();
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['store'] ?? 0);
    $store = $id > 0 ? q('SELECT * FROM stores WHERE id = ?', [$id])->fetch() : null;

    if ($action === 'password' && $store) {
        $password = trim((string)($_POST['new_password'] ?? ''));
        if ($problem = password_problem($password)) {
            $error = $problem;
        } else {
            q('UPDATE stores SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $id]);
            $message = 'New password set for ' . $store['name'] . '. Tell the owner: ' . $password;
        }
    } elseif ($action === 'phone' && $store) {
        $phone = normalize_phone((string)($_POST['new_phone'] ?? ''));
        if ($phone === '') {
            $error = 'That is not a mobile number.';
        } else {
            q('UPDATE stores SET phone = ? WHERE id = ?', [$phone, $id]);
            $message = $store['name'] . ' now signs in with ' . show_phone($phone) . '.';
        }
    } elseif ($action === 'unlink' && $store) {
        q("UPDATE stores SET token_hash = '' WHERE id = ?", [$id]);
        $message = $store['name'] . ' is unlinked. Its sales stay here; turning on online reports in Tillo Retail links it again.';
    } elseif ($action === 'support_password') {
        $password = (string)($_POST['new_support'] ?? '');
        if (mb_strlen($password) < 10) {
            $error = 'Use at least 10 characters for the support password.';
        } else {
            $config = config();
            $config['support_hash'] = password_hash($password, PASSWORD_DEFAULT);
            write_config($config);
            $message = 'Support password changed.';
        }
    } elseif ($action === 'migrate') {
        migrate(db());
        $message = 'Database tables are up to date.';
    } elseif ($action === 'signout') {
        sign_out();
        header('Location: /support');
        exit;
    }
}

$search = trim((string)($_GET['q'] ?? ''));
$params = [];
$where = '';
if ($search !== '') {
    $phone = normalize_phone($search);
    $where = 'WHERE s.name LIKE ? OR s.city LIKE ?' . ($phone !== '' ? ' OR s.phone = ?' : '');
    $params = ['%' . $search . '%', '%' . $search . '%'];
    if ($phone !== '') {
        $params[] = $phone;
    }
}
$stores = q("SELECT s.*, (SELECT COUNT(*) FROM sales x WHERE x.store_id = s.id) AS sale_count FROM stores s $where ORDER BY s.last_sync_at DESC, s.id DESC LIMIT 200", $params)->fetchAll();
$count = (int)q('SELECT COUNT(*) FROM stores')->fetchColumn();

$nav = '<nav class="top-nav"><form method="post">' . csrf_field() . '<input type="hidden" name="action" value="signout"><button class="top-link linklike" type="submit">Sign out</button></form></nav>';
page_start('Support', ['nav' => $nav, 'body' => 'page-support']);
?>
<h1>Shops (<?= num($count) ?>)</h1>
<?php if ($message): ?><div class="alert ok"><?= h($message) ?></div><?php endif ?>
<?php if ($error): ?><div class="alert"><?= h($error) ?></div><?php endif ?>

<form method="get" class="searchbar">
    <input type="search" name="q" value="<?= h($search) ?>" placeholder="Mobile number, shop or city" aria-label="Search">
    <button class="btn btn-small" type="submit">Find</button>
</form>

<?php foreach ($stores as $s): ?>
    <section class="card shop">
        <div class="shop-head">
            <div><strong><?= h($s['name']) ?></strong><?= $s['city'] ? ' · ' . h($s['city']) : '' ?>
                <div class="muted small"><?= h(show_phone($s['phone'])) ?> · version <?= h($s['app_version'] ?? '?') ?> · <?= num($s['sale_count']) ?> bills
                    · last update <?= h(ago($s['last_sync_at'])) ?> · last sign-in <?= h(ago($s['last_login_at'])) ?>
                    <?= $s['token_hash'] === '' ? ' · <strong>unlinked</strong>' : '' ?></div></div>
        </div>
        <details>
            <summary>Change sign-in</summary>
            <form method="post" class="inline">
                <?= csrf_field() ?><input type="hidden" name="action" value="password"><input type="hidden" name="store" value="<?= (int)$s['id'] ?>">
                <input name="new_password" placeholder="New password" required minlength="4" autocomplete="off">
                <button class="btn btn-small" type="submit">Set password</button>
            </form>
            <form method="post" class="inline">
                <?= csrf_field() ?><input type="hidden" name="action" value="phone"><input type="hidden" name="store" value="<?= (int)$s['id'] ?>">
                <input name="new_phone" type="tel" placeholder="New mobile number" required>
                <button class="btn btn-small btn-light" type="submit">Change number</button>
            </form>
            <form method="post" class="inline" onsubmit="return confirm('Unlink this shop? Its computer stops sending until online reports are turned on there again.')">
                <?= csrf_field() ?><input type="hidden" name="action" value="unlink"><input type="hidden" name="store" value="<?= (int)$s['id'] ?>">
                <button class="btn btn-small btn-light" type="submit">Unlink, so it can link again</button>
            </form>
        </details>
    </section>
<?php endforeach ?>
<?php if (!$stores): ?><p class="empty">No shops<?= $search !== '' ? ' found' : ' yet' ?>.</p><?php endif ?>

<section class="card">
    <h3>Support settings</h3>
    <form method="post" class="inline">
        <?= csrf_field() ?><input type="hidden" name="action" value="support_password">
        <input name="new_support" type="password" placeholder="New support password" required minlength="10" autocomplete="new-password">
        <button class="btn btn-small" type="submit">Change support password</button>
    </form>
    <form method="post" class="inline">
        <?= csrf_field() ?><input type="hidden" name="action" value="migrate">
        <button class="btn btn-small btn-light" type="submit">Update database tables</button>
    </form>
</section>
<?php
page_end();
