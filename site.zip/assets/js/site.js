/* Tillo website: the menu on small screens, the screens (filter and full-size viewer), and the latest Tillo Retail
   release from GitHub. */
(function () {
    "use strict";

    document.querySelectorAll("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

    // Menu (small screens)
    var toggle = document.querySelector("[data-menu-toggle]");
    var nav = document.getElementById("site-nav");
    if (toggle && nav) {
        toggle.addEventListener("click", function () {
            var open = nav.classList.toggle("open");
            toggle.setAttribute("aria-expanded", open ? "true" : "false");
        });
        nav.addEventListener("click", function (e) {
            if (e.target.closest("a")) { nav.classList.remove("open"); toggle.setAttribute("aria-expanded", "false"); }
        });
    }

    // Screens: show one group at a time
    var filters = Array.prototype.slice.call(document.querySelectorAll("[data-filter]"));
    var screens = Array.prototype.slice.call(document.querySelectorAll(".screen"));
    filters.forEach(function (button) {
        button.addEventListener("click", function () {
            var group = button.getAttribute("data-filter");
            filters.forEach(function (b) { b.setAttribute("aria-pressed", b === button ? "true" : "false"); });
            screens.forEach(function (s) { s.hidden = group !== "all" && s.getAttribute("data-group") !== group; });
        });
    });

    // Screens: full size in a viewer, with previous and next. Without the viewer the link opens the picture itself.
    var viewer = document.getElementById("viewer");
    if (viewer && typeof viewer.showModal === "function") {
        var image = document.getElementById("viewer-img");
        var title = document.getElementById("viewer-title");
        var caption = document.getElementById("viewer-caption");
        var current = 0;
        var items = function () {
            return Array.prototype.slice.call(document.querySelectorAll("[data-viewer-item]"))
                .filter(function (a) { return !a.closest("[hidden]"); });
        };
        var show = function (index) {
            var list = items();
            if (!list.length) return;
            current = (index + list.length) % list.length;
            var a = list[current];
            image.src = a.getAttribute("href");
            image.alt = a.querySelector("img").alt;
            title.textContent = a.getAttribute("data-title");
            caption.textContent = a.getAttribute("data-caption");
        };
        document.querySelectorAll("[data-viewer-item]").forEach(function (a) {
            a.addEventListener("click", function (e) {
                e.preventDefault();
                show(items().indexOf(a));
                viewer.showModal();
            });
        });
        viewer.querySelector("[data-viewer-prev]").addEventListener("click", function () { show(current - 1); });
        viewer.querySelector("[data-viewer-next]").addEventListener("click", function () { show(current + 1); });
        viewer.querySelector("[data-viewer-close]").addEventListener("click", function () { viewer.close(); });
        viewer.addEventListener("click", function (e) { if (e.target === viewer) viewer.close(); });
        viewer.addEventListener("keydown", function (e) {
            if (e.key === "ArrowRight") { e.preventDefault(); show(current + 1); }
            if (e.key === "ArrowLeft") { e.preventDefault(); show(current - 1); }
        });
    }

    // The program runs on Windows: on a phone, offer to send the link to the shop's computer instead.
    if (!/Windows/i.test(navigator.userAgent)) {
        document.querySelectorAll("[data-not-windows]").forEach(function (el) { el.hidden = false; });
    }
    var pageLink = location.protocol.indexOf("http") === 0 ? location.origin + "/download" : "https://github.com/qadeer37/tillo-retail/releases/latest";
    document.querySelectorAll("[data-share-link]").forEach(function (a) {
        a.href = "https://wa.me/?text=" + encodeURIComponent("Tillo Retail for the shop computer: " + pageLink);
    });
    document.querySelectorAll("[data-copy-link]").forEach(function (button) {
        button.addEventListener("click", function () {
            var done = function () { button.textContent = "Link copied"; };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(pageLink).then(done, function () { window.prompt("Copy this link:", pageLink); });
            } else {
                window.prompt("Copy this link:", pageLink);
            }
        });
    });

    // The newest Tillo Retail release: its installer, version, size and date. The links already point at the newest
    // release's TilloRetail-Setup.msi, so this only fills in the details (and finds the installer by any name).
    var REPO = "qadeer37/tillo-retail";
    var KEY = "tillo.retail.release";
    var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    function apply(r) {
        if (!r || !r.url) return;
        document.querySelectorAll('[data-download="retail"]').forEach(function (a) { a.href = r.url; });
        document.querySelectorAll("[data-release]").forEach(function (el) {
            var value = r[el.getAttribute("data-release")];
            if (value) el.textContent = value;
        });
        document.querySelectorAll("[data-release-line]").forEach(function (el) {
            el.textContent = "Version " + r.version + " for Windows 10 and 11, " + r.size + ".";
        });
    }

    function read() {
        try {
            var saved = JSON.parse(sessionStorage.getItem(KEY) || "null");
            if (saved && Date.now() - saved.at < 30 * 60 * 1000) return saved.release;
        } catch (e) { }
        return null;
    }

    function save(release) {
        try { sessionStorage.setItem(KEY, JSON.stringify({ at: Date.now(), release: release })); } catch (e) { }
    }

    if (!document.querySelector('[data-download="retail"], [data-release], [data-release-line]')) return;
    var cached = read();
    if (cached) { apply(cached); return; }
    if (!window.fetch) return;
    fetch("https://api.github.com/repos/" + REPO + "/releases/latest", { headers: { Accept: "application/vnd.github+json" } })
        .then(function (response) { return response.ok ? response.json() : null; })
        .then(function (data) {
            if (!data || !data.assets) return;
            var msi = data.assets.filter(function (a) { return a.name === "TilloRetail-Setup.msi"; })[0] ||
                      data.assets.filter(function (a) { return /\.msi$/i.test(a.name); })[0];
            if (!msi) return;
            var date = new Date(data.published_at);
            var release = {
                url: msi.browser_download_url,
                version: String(data.tag_name || "").replace(/^v/i, ""),
                size: Math.round(msi.size / 1048576) + " MB",
                date: date.getDate() + " " + MONTHS[date.getMonth()] + " " + date.getFullYear()
            };
            save(release);
            apply(release);
        })
        .catch(function () { });
})();
