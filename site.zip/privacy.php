<?php
// /privacy: the privacy policy of Tillo Retail, the Android app (Google Play, code name Tillo Mobile) and the Windows program. Google Play links
// to it from the store listing. Keep it in step with the Data safety form in Play Console.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

page_start('Privacy policy', ['body' => 'page-login']);
?>
<section class="login delete-account privacy">
    <h1>Privacy policy</h1>
    <p class="lead">For <strong>Tillo Retail</strong>, the Android app on Google Play and the Windows program, made by
        Tillo Retail, Pakistan. Last updated 21 October 2026.</p>

    <p>Tillo is a point of sale for shops. The shop's products, sales, khata and settings are kept on the shop's own phone
        or computer. Nothing leaves it unless the shop turns on one of the optional services below.</p>

    <h2>What stays on the phone</h2>
    <ul>
        <li><strong>Shop data:</strong> products, stock, sales, receipts, customers and their khata, deliveries and settings.</li>
        <li><strong>Camera:</strong> used only to read barcodes, on the phone. No picture or video is kept or sent.</li>
        <li><strong>Bluetooth:</strong> used only to find and print to the shop's receipt printer. On Android 11 and older,
            Android requires location permission for this; Tillo never reads the phone's location.</li>
        <li><strong>WhatsApp:</strong> receipts and reminders are handed to WhatsApp for the shop to send. Tillo does not
            read or keep messages.</li>
    </ul>

    <h2>Optional: Google backup</h2>
    <p>If the shop turns on backup, Tillo signs in with the shop's Google account and saves a copy of the shop's data in a
        hidden folder of that account's own Google Drive. Tillo uses the account's email address only to show which
        account is used. The backup goes to Google, not to Tillo, under Google's privacy policy; the shop can delete it in
        Google Drive › Settings › Manage apps.</p>

    <h2>Optional: online reports (my.tillopro.com)</h2>
    <p>If the shop turns on online reports, Tillo sends to Tillo Cloud (my.tillopro.com, hosted by Hostinger): the
        shop's name, city and mobile number, a password (stored only as a secure hash), an account id, and each sale,
        return, cancelled bill and delivery, with product names, amounts, khata (udhaar) amounts and the customer or
        supplier name written on it. This lets the owner see the shop's sales from any phone. It is sent encrypted
        (HTTPS).</p>

    <h2>License keys</h2>
    <p>When a shop buys a license, it sends Tillo its phone's or computer's code. Tillo keeps the shop's name, mobile
        number, that code and the key it made, so a paid license can be given again on a new phone or computer.</p>

    <h2>Google's barcode reader</h2>
    <p>Tillo reads barcodes with Google's ML Kit, which runs on the phone. ML Kit may send Google diagnostic information
        such as the phone model, the app's version and how well the reader performs, under Google's privacy policy. It
        does not send the pictures or the codes read.</p>

    <h2>What Tillo does not do</h2>
    <ul>
        <li>No ads, and no advertising or tracking libraries.</li>
        <li>Tillo never sells data, and shares it with no one except the services named above that run Tillo's features.</li>
        <li>Tillo is made for shop owners and their staff, and is not meant for children.</li>
    </ul>

    <h2>Keeping and deleting data</h2>
    <p>Online-reports data is kept while the shop's account exists. The shop can delete the account and everything it
        sent at any time, in the app (More › Online reports) or at <a href="/delete">my.tillopro.com/delete</a>; it is
        deleted at once. To have a license record or anything else removed, ask on WhatsApp.</p>

    <h2>Questions</h2>
    <p>WhatsApp or call <a href="https://wa.me/923123245056">0312-3245056</a>. If this policy changes, the new version is
        posted on this page with its date.</p>
</section>
<?php
page_end();
