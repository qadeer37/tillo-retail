<?php
// /pc/<pair code>: the QR a computer shows to join a shop (Tillo on computer). Tillo on the shop's phone opens this
// address itself (Android App Link); this page is for anything else that opens it: a phone without Tillo, or a scan
// from another app. It says what to do. /pc alone will be Tillo on computer itself.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

$pair = (string)($_GET['pair'] ?? '');
$valid = preg_match('/^[0-9a-f]{32}$/', $pair) === 1;
$play = 'https://play.google.com/store/apps/details?id=com.tilloretail.mobile&referrer=utm_source%3Dpc_code';

page_start('Connect a computer', ['body' => 'page-login']);
?>
<section class="login">
<?php if ($valid): ?>
    <h1>Connect this computer to your shop</h1>
    <p class="lead">This code is for <strong>Tillo</strong> on your shop's main phone.</p>
    <ol>
        <li>Open Tillo on the main phone.</li>
        <li>Go to <strong>More › Phones &amp; computers › Connect a computer</strong>.</li>
        <li>Point the phone at the code on the computer.</li>
    </ol>
    <p><a class="button" href="intent://my.tillopro.com/pc/<?= h($pair) ?>#Intent;scheme=https;package=com.tilloretail.mobile;S.browser_fallback_url=<?= h(rawurlencode($play)) ?>;end">Open in Tillo</a></p>
    <p>No Tillo on this phone? <a href="<?= h($play) ?>">Get it free on Google Play</a>.</p>
<?php else: ?>
    <h1>Tillo on computer</h1>
    <p class="lead">Coming soon: your shop's Tillo on any computer, joined with your phone.</p>
    <p><a href="<?= h($play) ?>">Get Tillo free on Google Play</a></p>
<?php endif; ?>
</section>
<?php
page_end();
