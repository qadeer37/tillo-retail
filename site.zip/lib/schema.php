<?php
// The database tables, for MySQL (Hostinger) and SQLite (tests on a developer's computer). Every statement can run again
// safely (CREATE ... IF NOT EXISTS), so setup.php and migrate() can apply it to a database that already has tables.
//
// Amounts are rupees with paisa (the app keeps them exact; pages show whole rupees). Returns are stored like sales, with
// positive amounts, and type 2; reports subtract them. A voided sale keeps its row with status 2 and counts nowhere.

declare(strict_types=1);

function schema_statements(bool $sqlite): array
{
    $id = $sqlite ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT NOT NULL AUTO_INCREMENT PRIMARY KEY';
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $money = 'DECIMAL(14,2) NOT NULL DEFAULT 0';
    $amount = 'DECIMAL(14,3) NOT NULL DEFAULT 0';

    $tables = [
        // One row per shop (a Tillo Retail database). uid is the app's StoreId; the app proves it is the shop with
        // its token, of which only the sha256 is kept.
        "CREATE TABLE IF NOT EXISTS stores (
            id $id,
            uid VARCHAR(36) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            name VARCHAR(120) NOT NULL,
            name_ur VARCHAR(120) NULL,
            city VARCHAR(80) NULL,
            phone VARCHAR(20) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            app_version VARCHAR(20) NULL,
            created_at DATETIME NOT NULL,
            last_sync_at DATETIME NULL,
            last_login_at DATETIME NULL
        )$tail",

        "CREATE TABLE IF NOT EXISTS sales (
            store_id INT NOT NULL,
            sale_id INT NOT NULL,
            number BIGINT NOT NULL,
            type SMALLINT NOT NULL,
            status SMALLINT NOT NULL,
            business_date DATE NOT NULL,
            local_time DATETIME NOT NULL,
            hour SMALLINT NOT NULL,
            register VARCHAR(60) NULL,
            cashier VARCHAR(80) NULL,
            customer VARCHAR(120) NULL,
            original_number BIGINT NULL,
            line_count INT NOT NULL DEFAULT 0,
            quantity $amount,
            gross $money,
            discount $money,
            tax $money,
            fee $money,
            rounding $money,
            total $money,
            credit $money,
            cost $money,
            profit $money,
            void_reason VARCHAR(300) NULL,
            voided_at DATETIME NULL,
            PRIMARY KEY (store_id, sale_id)
        )$tail",

        "CREATE TABLE IF NOT EXISTS sale_lines (
            store_id INT NOT NULL,
            sale_id INT NOT NULL,
            line_no INT NOT NULL,
            product VARCHAR(160) NOT NULL,
            product_ur VARCHAR(160) NULL,
            category VARCHAR(80) NULL,
            unit VARCHAR(40) NULL,
            qty $amount,
            price $money,
            discount $money,
            amount $money,
            profit $money,
            PRIMARY KEY (store_id, sale_id, line_no)
        )$tail",

        "CREATE TABLE IF NOT EXISTS sale_payments (
            store_id INT NOT NULL,
            sale_id INT NOT NULL,
            n INT NOT NULL,
            method VARCHAR(60) NOT NULL,
            kind SMALLINT NOT NULL,
            amount $money,
            PRIMARY KEY (store_id, sale_id, n)
        )$tail",

        "CREATE TABLE IF NOT EXISTS purchases (
            store_id INT NOT NULL,
            receipt_id INT NOT NULL,
            number BIGINT NOT NULL,
            received_date DATE NOT NULL,
            supplier VARCHAR(120) NULL,
            bill_no VARCHAR(40) NULL,
            line_count INT NOT NULL DEFAULT 0,
            subtotal $money,
            discount $money,
            other_charges $money,
            total $money,
            paid $money,
            paid_with VARCHAR(60) NULL,
            received_by VARCHAR(80) NULL,
            PRIMARY KEY (store_id, receipt_id)
        )$tail",

        "CREATE TABLE IF NOT EXISTS purchase_lines (
            store_id INT NOT NULL,
            receipt_id INT NOT NULL,
            line_no INT NOT NULL,
            product VARCHAR(160) NOT NULL,
            unit VARCHAR(40) NULL,
            qty $amount,
            bonus $amount,
            cost $money,
            amount $money,
            PRIMARY KEY (store_id, receipt_id, line_no)
        )$tail",

        // Sign-in tries, to slow down password guessing.
        "CREATE TABLE IF NOT EXISTS login_attempts (
            id $id,
            k VARCHAR(100) NOT NULL,
            at INT NOT NULL
        )$tail",

        // Every license key Tillo Licensing has made (it sends them; lib/licensing.php). code is the computer's or phone's
        // code and license_key the key, both without dashes; product is Retail, School or Mobile.
        "CREATE TABLE IF NOT EXISTS licenses (
            id $id,
            product VARCHAR(10) NOT NULL,
            code CHAR(12) NOT NULL,
            license_key CHAR(64) NOT NULL,
            shop VARCHAR(160) NULL,
            phone VARCHAR(40) NULL,
            phone_norm VARCHAR(15) NULL,
            note VARCHAR(300) NULL,
            issued_at DATETIME NOT NULL,
            received_at DATETIME NOT NULL
        )$tail",

        // Two phones, one shop (Tillo Mobile, More > Phones). Only while a second phone is joined: a shop with one
        // phone has nothing here. The main phone is A, the joined one B; each proves itself with its own token, of
        // which only the sha256 is kept. acked_seq: the last change from the other phone it has applied. expired: B
        // wasn't seen for 30 days, so nothing more is kept for it (it scans a new code to join again).
        "CREATE TABLE IF NOT EXISTS phone_links (
            id $id,
            store_id INT NOT NULL,
            letter CHAR(1) NOT NULL,
            name VARCHAR(60) NULL,
            token_hash CHAR(64) NOT NULL,
            acked_seq BIGINT NOT NULL DEFAULT 0,
            expired SMALLINT NOT NULL DEFAULT 0,
            joined_at DATETIME NOT NULL,
            last_seen_at INT NOT NULL DEFAULT 0
        )$tail",

        // A join code shown as a QR on the main phone: one use, 10 minutes. Only the sha256 of the code is kept; the
        // copy of the shop it goes with is a file outside the public folder, deleted once the new phone has it.
        "CREATE TABLE IF NOT EXISTS phone_joins (
            code_hash CHAR(64) NOT NULL PRIMARY KEY,
            store_id INT NOT NULL,
            snapshot_seq BIGINT NOT NULL DEFAULT 0,
            snapshot_bytes INT NOT NULL DEFAULT 0,
            expires_at INT NOT NULL,
            used_at INT NULL
        )$tail",

        // Changes on their way from one phone to the other (a bill, a khata entry, a product...): deleted as soon as the
        // other phone says it has them. uid is the phone's own id for the change, so sending it again does nothing.
        "CREATE TABLE IF NOT EXISTS phone_changes (
            seq $id,
            store_id INT NOT NULL,
            from_letter CHAR(1) NOT NULL,
            uid VARCHAR(40) NOT NULL,
            kind VARCHAR(30) NOT NULL,
            body MEDIUMTEXT NOT NULL,
            at INT NOT NULL
        )$tail",

        // Active shops: each installed app checks in at most every few hours when it is opened (api/ping). One row per
        // installation (a random id the app makes; installed again, it is a new one). No sales amounts: only counts.
        "CREATE TABLE IF NOT EXISTS installs (
            id $id,
            install_id CHAR(36) NOT NULL,
            app VARCHAR(20) NOT NULL,
            app_version VARCHAR(20) NULL,
            version_code INT NULL,
            android SMALLINT NULL,
            shop_name VARCHAR(120) NULL,
            city VARCHAR(80) NULL,
            kind VARCHAR(40) NULL,
            lang VARCHAR(5) NULL,
            phone_letter CHAR(1) NULL,
            phones SMALLINT NOT NULL DEFAULT 1,
            products INT NOT NULL DEFAULT 0,
            bills_today INT NOT NULL DEFAULT 0,
            bills_7d INT NOT NULL DEFAULT 0,
            last_sale_date DATE NULL,
            backup SMALLINT NOT NULL DEFAULT 0,
            online SMALLINT NOT NULL DEFAULT 0,
            pings INT NOT NULL DEFAULT 0,
            days_seen INT NOT NULL DEFAULT 0,
            first_seen DATETIME NOT NULL,
            last_seen DATETIME NOT NULL
        )$tail",
    ];

    $indexes = [
        ['stores', 'ux_stores_uid', 'uid', true],
        ['stores', 'ix_stores_phone', 'phone', false],
        ['stores', 'ix_stores_token', 'token_hash', false],
        ['sales', 'ix_sales_date', 'store_id, business_date', false],
        ['purchases', 'ix_purchases_date', 'store_id, received_date', false],
        ['login_attempts', 'ix_login_attempts', 'k, at', false],
        ['licenses', 'ux_licenses_key', 'license_key', true],
        ['licenses', 'ix_licenses_code', 'code', false],
        ['licenses', 'ix_licenses_phone', 'phone_norm', false],
        ['phone_links', 'ux_phone_links_letter', 'store_id, letter', true],
        ['phone_links', 'ix_phone_links_token', 'token_hash', false],
        ['phone_joins', 'ix_phone_joins_store', 'store_id', false],
        ['phone_changes', 'ux_phone_changes_uid', 'store_id, uid', true],
        ['phone_changes', 'ix_phone_changes_seq', 'store_id, from_letter, seq', false],
        ['installs', 'ux_installs_id', 'install_id', true],
        ['installs', 'ix_installs_seen', 'last_seen', false],
    ];

    $statements = $tables;
    foreach ($indexes as [$table, $name, $columns, $unique]) {
        $kind = $unique ? 'UNIQUE INDEX' : 'INDEX';
        // MySQL has no CREATE INDEX IF NOT EXISTS; migrate() skips an index that exists.
        $statements[] = $sqlite
            ? "CREATE $kind IF NOT EXISTS $name ON $table ($columns)"
            : ['index', $table, $name, "CREATE $kind $name ON $table ($columns)"];
    }
    return $statements;
}

/** Creates the tables and indexes that are missing. */
function migrate(PDO $pdo): void
{
    $sqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
    foreach (schema_statements($sqlite) as $statement) {
        if (is_array($statement)) {
            [, $table, $name, $sql] = $statement;
            $exists = $pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?');
            $exists->execute([$table, $name]);
            if ((int)$exists->fetchColumn() === 0) {
                $pdo->exec($sql);
            }
            continue;
        }
        $pdo->exec($statement);
    }
}
