<?php
// POST /api/phones/photo?name=<photo>: a phone sends a product photo for the other phone. Authorization: Bearer
// <phone token>. The body is the photo's bytes. Kept until the other phone fetches it (/api/phones/fetch).

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
$name = photo_name($_GET['name'] ?? null);
if ($name === null) {
    json_error(400, 'The photo name is missing.');
}
$bytes = read_bytes(MAX_PHOTO_BYTES);
// Only for a phone that will fetch it: the other phone, or one about to join with the code the main phone shows.
$waiting = $phone['letter'] === 'A'
    && (int)q('SELECT COUNT(*) FROM phone_joins WHERE store_id = ? AND used_at IS NULL AND expires_at >= ?', [$storeId, time()])->fetchColumn() > 0;
if (other_phone($storeId, $phone['letter']) === null && !$waiting) {
    json_out(200, ['ok' => true, 'kept' => false]);
}
if (file_put_contents(photo_file($storeId, $name), $bytes, LOCK_EX) === false) {
    json_error(500, 'Could not keep the photo. Try again.');
}
json_out(200, ['ok' => true, 'kept' => true]);
