<?php
// POST /api/phones/photo?name=<photo>: a phone sends a product photo for the other phones. Authorization: Bearer
// <phone token>. The body is the photo's bytes. Kept until every other phone has fetched it (/api/phones/fetch).

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
$name = photo_name($_GET['name'] ?? null);
if ($name === null) {
    json_error(400, 'The photo name is missing.');
}
$bytes = read_bytes(MAX_PHOTO_BYTES);
// Only for phones that will fetch it: the other phones, or one about to join with the code the main phone shows.
if (other_phones($storeId, $phone['letter']) === [] && waiting_join($storeId) === null) {
    json_out(200, ['ok' => true, 'kept' => false]);
}
if (file_put_contents(photo_file($storeId, $name), $bytes, LOCK_EX) === false) {
    json_error(500, 'Could not keep the photo. Try again.');
}
save_photo_info($storeId, $name, ['from' => $phone['letter'], 'got' => []]);
save_photo_wants($storeId, array_filter(photo_wants($storeId), fn($n) => $n !== $name));
json_out(200, ['ok' => true, 'kept' => true]);
