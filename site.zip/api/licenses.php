<?php
// POST /api/licenses: Tillo Licensing sends the license keys it has made. It sends all of them each time: a key already
// here is updated, so a send that failed (no internet at the office) is simply made good by the next one.
// Authorization: Bearer <the token from /api/licensing>.
//
// {"licenses": [{"product": "Mobile", "code": "R2Z4-RDRP-5T0Q", "key": "CPV4-69SY-...", "shop": "Madina Store",
//   "phone": "0300 1234567", "note": "", "issued_at": "2026-10-20 11:30"}, ...]}
// →  {"ok": true, "saved": 12, "skipped": 0, "total": 12}

declare(strict_types=1);

require __DIR__ . '/../lib/licensing.php';

require_licensing_tool();
$data = read_json();
$list = $data['licenses'] ?? null;
if (!is_array($list) || !array_is_list($list)) {
    json_error(400, 'No licenses were sent.');
}
if (count($list) > 50000) {
    json_error(413, 'Too many licenses at once.');
}

[$saved, $skipped] = save_licenses($list);
json_out(200, ['ok' => true, 'saved' => $saved, 'skipped' => $skipped, 'total' => (int)q('SELECT COUNT(*) FROM licenses')->fetchColumn()]);
