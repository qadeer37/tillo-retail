<?php
// License keys made by Tillo Licensing (the developer's key-making tool on the office PC). It sends every key it makes to
// /api/licenses, so support can look up a shop from anywhere: before making a free key for a shop's new phone or
// computer, check its earlier key. The formats are Tillo's (TilloPro Licensing/src/TilloPro.Licensing/LicenseCodes.cs).

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

/** Crockford's Base32, as Tillo's codes and keys use it: no I, L, O or U. */
const LICENSE_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

/** The products Tillo Licensing makes keys for. */
const LICENSE_PRODUCTS = ['Retail', 'School', 'Mobile'];

/** Upper case without spaces and dashes; O, I and L count as 0, 1 and 1. Null when the text has anything else. */
function license_normalize(?string $text): ?string
{
    $text = (string)$text;
    if (trim($text) === '') {
        return null;
    }
    $out = '';
    foreach (mb_str_split($text) as $ch) {
        if (preg_match('/^\s$/u', $ch) || in_array($ch, ['-', '–', '—', '_', '.'], true)) {
            continue;
        }
        $c = strtoupper($ch);
        if ($c === 'O') {
            $c = '0';
        } elseif ($c === 'I' || $c === 'L') {
            $c = '1';
        }
        if (strlen($c) !== 1 || !str_contains(LICENSE_ALPHABET, $c)) {
            return null;
        }
        $out .= $c;
    }
    return $out;
}

/** A computer or phone code as its 12 characters, or null when it isn't one (its last character checks the others). */
function license_code(?string $text): ?string
{
    $code = license_normalize($text);
    if ($code === null || strlen($code) !== 12) {
        return null;
    }
    $total = 0;
    for ($i = 0; $i < 11; $i++) {
        $total += ($i + 1) * strpos(LICENSE_ALPHABET, $code[$i]);
    }
    return LICENSE_ALPHABET[$total % 31] === $code[11] ? $code : null;
}

/** "9CY2SQEC2B1E" → "9CY2-SQEC-2B1E"; a key in its 16 groups of 4 the same way. */
function license_group(string $text): string
{
    return implode('-', str_split($text, 4));
}

/** A license as Tillo Licensing sends it, ready for the table; null when it is missing something. */
function license_row(array $item): ?array
{
    $product = (string)($item['product'] ?? '');
    $product = in_array(ucfirst(strtolower($product)), LICENSE_PRODUCTS, true) ? ucfirst(strtolower($product)) : null;
    $code = license_code((string)($item['code'] ?? ''));
    $key = license_normalize((string)($item['key'] ?? ''));
    if ($product === null || $code === null || $key === null || strlen($key) !== 64) {
        return null;
    }
    $issued = trim((string)($item['issued_at'] ?? ''));
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $issued)) {
        $issued .= ':00';
    }
    $issued = valid_time($issued);
    if ($issued === null || $issued < '2020-01-01') {
        $issued = now_text();
    }
    $phone = clip($item['phone'] ?? null, 40);
    return [
        'product' => $product,
        'code' => $code,
        'license_key' => $key,
        'shop' => clip($item['shop'] ?? null, 160),
        'phone' => $phone,
        'phone_norm' => $phone === null ? null : (normalize_phone($phone) ?: null),
        'note' => clip($item['note'] ?? null, 300),
        'issued_at' => $issued,
    ];
}

/** Adds the licenses, or updates the ones already here (the same key). Returns how many were saved and skipped. */
function save_licenses(array $items): array
{
    $saved = 0;
    $skipped = 0;
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($items as $item) {
            $row = is_array($item) ? license_row($item) : null;
            if ($row === null) {
                $skipped++;
                continue;
            }
            $id = q('SELECT id FROM licenses WHERE license_key = ?', [$row['license_key']])->fetchColumn();
            if ($id) {
                q('UPDATE licenses SET product = ?, code = ?, shop = ?, phone = ?, phone_norm = ?, note = ?, issued_at = ? WHERE id = ?', [
                    $row['product'], $row['code'], $row['shop'], $row['phone'], $row['phone_norm'], $row['note'], $row['issued_at'], $id,
                ]);
            } else {
                q('INSERT INTO licenses (product, code, license_key, shop, phone, phone_norm, note, issued_at, received_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                    $row['product'], $row['code'], $row['license_key'], $row['shop'], $row['phone'], $row['phone_norm'], $row['note'],
                    $row['issued_at'], now_text(),
                ]);
            }
            $saved++;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return [$saved, $skipped];
}

/** Stops the request unless it carries Tillo Licensing's token (Authorization: Bearer ...), from /api/licensing. */
function require_licensing_tool(): void
{
    $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    $expected = (string)(config()['licensing_token_hash'] ?? '');
    if (!preg_match('/^Bearer\s+([0-9a-f]{64})$/i', trim($header), $m) || $expected === ''
        || !hash_equals($expected, hash('sha256', strtolower($m[1])))) {
        json_error(401, 'Tillo Licensing is not connected. Connect it again with the support password.');
    }
}
