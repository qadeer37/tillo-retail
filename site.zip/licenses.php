<?php
// Tillo support: every license key Tillo Licensing has made (it sends them here; lib/licensing.php). Before making a free
// key for a shop's new phone or computer, look the shop up: by its name, mobile number, the old code or the note.
// Tillo Mobile shows the old phone's code when a restored backup holds a key for another phone.

declare(strict_types=1);

require __DIR__ . '/lib/view.php';
require __DIR__ . '/lib/licensing.php';
require __DIR__ . '/lib/schema.php';

if (!is_support()) {
    header('Location: /support');
    exit;
}

$search = trim((string)($_GET['q'] ?? ''));
$product = (string)($_GET['product'] ?? '');
$product = in_array($product, LICENSE_PRODUCTS, true) ? $product : '';

$where = [];
$params = [];
if ($search !== '') {
    $any = ['shop LIKE ?', 'note LIKE ?', 'phone LIKE ?'];
    array_push($params, '%' . $search . '%', '%' . $search . '%', '%' . $search . '%');
    $phone = normalize_phone($search);
    if ($phone !== '') {
        $any[] = 'phone_norm = ?';
        $params[] = $phone;
    }
    $code = license_normalize($search);
    if ($code !== null && strlen($code) >= 4) {
        $any[] = 'code LIKE ?';
        $params[] = '%' . $code . '%';
        if (strlen($code) >= 8) {
            $any[] = 'license_key LIKE ?';
            $params[] = '%' . $code . '%';
        }
    }
    $where[] = '(' . implode(' OR ', $any) . ')';
}
if ($product !== '') {
    $where[] = 'product = ?';
    $params[] = $product;
}
$sql = 'SELECT * FROM licenses' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY issued_at DESC, id DESC LIMIT 300';
try {
    $rows = q($sql, $params)->fetchAll();
} catch (PDOException) {
    // A database set up before the list existed, opened before Tillo Licensing connected: add the table, as "Update
    // database tables" on /support would.
    migrate(db());
    $rows = q($sql, $params)->fetchAll();
}

$counts = array_fill_keys(LICENSE_PRODUCTS, 0);
foreach (q('SELECT product, COUNT(*) AS n FROM licenses GROUP BY product')->fetchAll() as $row) {
    $counts[$row['product']] = (int)$row['n'];
}
$total = array_sum($counts);
$newest = q('SELECT MAX(received_at) FROM licenses')->fetchColumn() ?: null;
$connected = config()['licensing_connected_at'] ?? null;

/** The address of this page with the search and product filter. */
function licenses_link(string $search, string $product): string
{
    $query = http_build_query(array_filter(['q' => $search, 'product' => $product], fn ($v) => $v !== ''));
    return '/licenses' . ($query === '' ? '' : '?' . $query);
}

$nav = '<nav class="top-nav"><a class="top-link" href="/support">Shops</a><form method="post" action="/support">' . csrf_field()
    . '<input type="hidden" name="action" value="signout"><button class="top-link linklike" type="submit">Sign out</button></form></nav>';
page_start('License keys', ['nav' => $nav, 'body' => 'page-support']);
?>
<h1>License keys (<?= num($total) ?>)</h1>
<p class="note">
    Made with Tillo Licensing on the office computer, which sends every key here.
    <?= $connected ? 'Connected ' . h(ago((string)$connected)) . '.' : '<strong>Tillo Licensing is not connected yet</strong>: in it, press Connect to Tillo Cloud and type the support password.' ?>
    <?= $newest ? 'Newest key received ' . h(ago((string)$newest)) . '.' : '' ?>
</p>

<form method="get" class="searchbar">
    <input type="search" name="q" value="<?= h($search) ?>" placeholder="Shop, mobile number, phone or computer code, or note" aria-label="Search">
    <?php if ($product !== ''): ?><input type="hidden" name="product" value="<?= h($product) ?>"><?php endif ?>
    <button class="btn btn-small" type="submit">Find</button>
</form>

<div class="periods">
    <a class="chip<?= $product === '' ? ' on' : '' ?>" href="<?= h(licenses_link($search, '')) ?>">All · <?= num($total) ?></a>
    <?php foreach (LICENSE_PRODUCTS as $name): ?>
        <a class="chip<?= $product === $name ? ' on' : '' ?>" href="<?= h(licenses_link($search, $name)) ?>">Tillo <?= h($name) ?> · <?= num($counts[$name]) ?></a>
    <?php endforeach ?>
</div>

<?php if ($rows): ?>
    <section class="card">
        <div class="table-scroll">
            <table class="table licenses">
                <thead>
                <tr><th>Made</th><th>Shop</th><th>Phone</th><th>Computer or phone code</th><th>License key</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $l): ?>
                    <tr>
                        <td class="nowrap"><?= h(date('j M Y', strtotime($l['issued_at']))) ?><div class="muted small"><?= h(date('g:i a', strtotime($l['issued_at']))) ?></div></td>
                        <td><span class="tag"><?= h($l['product']) ?></span> <?= h($l['shop'] ?? '') ?>
                            <?php if ($l['note']): ?><div class="muted small"><?= h($l['note']) ?></div><?php endif ?></td>
                        <td class="nowrap"><?= h($l['phone'] ?? '') ?></td>
                        <td class="code"><?= h(license_group($l['code'])) ?></td>
                        <td class="key"><?= h(license_group($l['license_key'])) ?></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php if (count($rows) === 300): ?><p class="muted small">The newest 300 are shown. Search to find older ones.</p><?php endif ?>
    </section>
<?php else: ?>
    <p class="empty"><?= $search !== '' || $product !== '' ? 'No license keys found.' : 'No license keys yet.' ?></p>
<?php endif ?>
<?php
page_end();
