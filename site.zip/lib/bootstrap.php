<?php
// Tillo Cloud (my.tillopro.com): shops' sales, returns and purchases sent by Tillo Retail, and the owners' reports.
// Every page and API script starts with: require __DIR__ . '/lib/bootstrap.php';
//
// The settings file (database password, support password) lives outside the public folder, next to it:
//   /home/<account>/domains/my.tillopro.com/tillo-cloud-config.php
// It is written once by setup.php and never by a deploy, so deploying never touches it.

declare(strict_types=1);

date_default_timezone_set('Asia/Karachi');
mb_internal_encoding('UTF-8');

/** sha256 of the one-time setup secret (the secret itself is never stored here). */
const TILLO_SETUP_HASH = '5fb07b6a5672dfef40d8c9ce9a3c0a8ecb612e2fc33ec741eb20fa81764b74af';

/** Longest date range a report covers. */
const MAX_REPORT_DAYS = 400;

require_once __DIR__ . '/util.php';

function config_path(): string
{
    $override = getenv('TILLO_CONFIG');
    return $override !== false && $override !== '' ? $override : dirname(__DIR__, 2) . '/tillo-cloud-config.php';
}

/** The settings, or null before setup. */
function config(): ?array
{
    static $config = false;
    if ($config === false) {
        $file = config_path();
        $config = is_file($file) ? require $file : null;
        if (!is_array($config)) {
            $config = null;
        }
    }
    return $config;
}

/** Saves the settings file (readable only by this hosting account). */
function write_config(array $config): void
{
    $file = config_path();
    $temp = $file . '.tmp';
    $text = "<?php\n// Tillo Cloud settings, written by setup.php. Keep this file private.\nreturn " . var_export($config, true) . ";\n";
    if (file_put_contents($temp, $text, LOCK_EX) === false) {
        throw new RuntimeException('Could not write ' . $temp);
    }
    @chmod($temp, 0600);
    if (!rename($temp, $file)) {
        throw new RuntimeException('Could not write ' . $file);
    }
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $config = config();
        if ($config === null) {
            http_response_code(503);
            exit('Tillo Cloud is not set up yet.');
        }
        $pdo = connect($config['db']);
    }
    return $pdo;
}

function connect(array $db): PDO
{
    $pdo = new PDO($db['dsn'], $db['user'] ?? null, $db['pass'] ?? null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    if (str_starts_with($db['dsn'], 'sqlite:')) {
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 5000');
    } else {
        $pdo->exec("SET time_zone = '+05:00'");
    }
    return $pdo;
}

function is_sqlite(): bool
{
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
}

/** Runs a query and returns the statement. */
function q(string $sql, array $params = []): PDOStatement
{
    // A sync inserts many lines with the same statement: prepare each one once per request.
    static $prepared = [];
    $statement = $prepared[$sql] ??= db()->prepare($sql);
    $statement->execute($params);
    return $statement;
}

function now_text(): string
{
    return date('Y-m-d H:i:s');
}
