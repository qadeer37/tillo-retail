<?php
// Two phones, one shop (Tillo Mobile, More > Phones). The main phone (A) shows a QR code; the second phone (B) scans
// it, downloads a copy of the shop once, and from then on the two send each other their changes through here. Nothing
// is kept longer than it takes to reach the other phone: a change goes as soon as the other phone has it, the copy of
// the shop as soon as B has it, a photo as soon as it is fetched. A shop with one phone has nothing here at all.
//
// Every phone proves itself with its own token (Authorization: Bearer <64 hex>); only the sha256 is kept.

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

/** Phones a shop may have: the main phone and one more. */
const MAX_PHONES = 2;
/** How long a join code works. */
const JOIN_SECONDS = 600;
/** A second phone not seen for this long is let go: nothing more is kept for it. */
const PHONE_GONE_SECONDS = 30 * 86400;
/** Changes in one request, each way. */
const MAX_CHANGES = 500;
/** Largest copy of a shop, and largest photo. */
const MAX_SNAPSHOT_BYTES = 40 * 1024 * 1024;
const MAX_PHOTO_BYTES = 1024 * 1024;

/** The folder for copies of shops and photos on their way: next to the settings file, never in the public folder. */
function phone_files_dir(): string
{
    $dir = dirname(config_path()) . '/tillo-phone-files';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    return $dir;
}

function snapshot_file(int $storeId, string $codeHash): string
{
    return phone_files_dir() . '/shop-' . $storeId . '-' . substr($codeHash, 0, 32) . '.bin';
}

/** A product photo's name as the app makes them (letters, digits, dot, dash, underscore), or null. */
function photo_name(mixed $name): ?string
{
    return is_string($name) && preg_match('/^[A-Za-z0-9._-]{1,80}$/', $name) && !str_starts_with($name, '.') ? $name : null;
}

function photo_file(int $storeId, string $name): string
{
    return phone_files_dir() . '/photo-' . $storeId . '-' . $name;
}

/** The phone whose token came with the request (and its shop), or an error answer. A removed phone is told so (410). */
function api_phone(): array
{
    $header = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (!preg_match('/^Bearer\s+([0-9a-f]{64})$/i', trim($header), $m)) {
        json_error(401, 'This phone is not joined to a shop.');
    }
    $phone = q('SELECT * FROM phone_links WHERE token_hash = ?', [hash('sha256', strtolower($m[1]))])->fetch();
    if (!$phone) {
        json_out(410, ['ok' => false, 'removed' => true, 'error' => 'This phone was removed from the shop. Scan a new code on the main phone to join again.']);
    }
    if ((int)$phone['expired'] === 1) {
        json_out(410, ['ok' => false, 'removed' => true, 'error' => 'This phone was not used for 30 days, so it left the shop. Scan a new code on the main phone to join again.']);
    }
    q('UPDATE phone_links SET last_seen_at = ? WHERE id = ?', [time(), $phone['id']]);
    $phone['last_seen_at'] = time();
    return $phone;
}

/** The shop's phones, for the Phones screen: [{letter, name, last_seen (seconds ago), expired}]. */
function phone_list(int $storeId): array
{
    $now = time();
    $list = [];
    foreach (q('SELECT letter, name, last_seen_at, expired FROM phone_links WHERE store_id = ? ORDER BY letter', [$storeId])->fetchAll() as $row) {
        $list[] = [
            'letter' => $row['letter'],
            'name' => $row['name'],
            'last_seen' => max(0, $now - (int)$row['last_seen_at']),
            'expired' => (int)$row['expired'] === 1,
        ];
    }
    return $list;
}

/** Lets B go when it hasn't been seen for 30 days: its waiting changes are deleted and nothing more is kept for it. */
function expire_quiet_phones(int $storeId): void
{
    $quiet = q("SELECT id FROM phone_links WHERE store_id = ? AND letter <> 'A' AND expired = 0 AND last_seen_at < ?",
        [$storeId, time() - PHONE_GONE_SECONDS])->fetchAll();
    foreach ($quiet as $row) {
        q('UPDATE phone_links SET expired = 1 WHERE id = ?', [$row['id']]);
        // What A sent for it, and what it sent that A has: nobody needs either any more.
        q('DELETE FROM phone_changes WHERE store_id = ?', [$storeId]);
        delete_photos($storeId);
    }
}

/** The other phone of a shop that is still joined (not expired), or null. */
function other_phone(int $storeId, string $letter): ?array
{
    $row = q('SELECT * FROM phone_links WHERE store_id = ? AND letter <> ? AND expired = 0', [$storeId, $letter])->fetch();
    return $row ?: null;
}

/** Deletes join codes that ran out or were used, with their copies of the shop. */
function delete_old_joins(int $storeId, bool $all = false): void
{
    $rows = $all
        ? q('SELECT code_hash FROM phone_joins WHERE store_id = ?', [$storeId])->fetchAll()
        : q('SELECT code_hash FROM phone_joins WHERE store_id = ? AND expires_at < ? AND used_at IS NULL', [$storeId, time()])->fetchAll();
    foreach ($rows as $row) {
        @unlink(snapshot_file($storeId, $row['code_hash']));
        q('DELETE FROM phone_joins WHERE code_hash = ?', [$row['code_hash']]);
    }
}

function delete_photos(int $storeId): void
{
    foreach (glob(phone_files_dir() . '/photo-' . $storeId . '-*') ?: [] as $file) {
        @unlink($file);
    }
}

/** Everything a shop's phones had here: back to one phone, as if it never had two. */
function phones_forget_store(int $storeId): void
{
    delete_old_joins($storeId, true);
    delete_photos($storeId);
    q('DELETE FROM phone_changes WHERE store_id = ?', [$storeId]);
    q('DELETE FROM phone_links WHERE store_id = ?', [$storeId]);
}

/** The raw body of a POST (a copy of the shop, a photo), or an error answer when it is missing or too big. */
function read_bytes(int $max): string
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_error(405, 'Use POST.');
    }
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > $max) {
        json_error(413, 'Too big.');
    }
    $bytes = file_get_contents('php://input', false, null, 0, $max + 1);
    if ($bytes === false || $bytes === '') {
        json_error(400, 'Nothing was sent.');
    }
    if (strlen($bytes) > $max) {
        json_error(413, 'Too big.');
    }
    return $bytes;
}

/** Sends a file as the answer, then stops. */
function send_file(string $file): never
{
    header('Content-Type: application/octet-stream');
    header('Cache-Control: no-store');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
