<?php
// Steps: how far each installation of Tillo Mobile (0.9.9 and later) has got, sent with its check-in (api/ping). The
// first time it does each thing on the way to using Tillo (setting up, the first bill, the first receipt printed...), as
// seconds after Tillo was installed on that phone; -1 for what a shop had done before the app kept steps. Never what was
// sold, amounts, names or products: only that a step happened, and when. lib/insights.php reads them.

declare(strict_types=1);

/** The steps the app sends (cloud/Steps.kt): anything else is dropped. */
const STEP_NAMES = [
    // Setting up, in order: Start on the first screen (or Restore, or Join as a second phone), Next on "Your shop", Sell.
    'start', 'restore', 'join', 'setup', 'sell',
    // Had Tillo before it kept steps (updated from an older version): -1, and not a new shop.
    'old',
    // Selling: the first item on a bill, the first bill, the tenth.
    'cart', 'bill', 'bill10',
    // Everything else, the first time.
    'product', 'import', 'printer', 'print', 'whatsapp', 'customer', 'khata', 'purchase', 'expense', 'backup', 'phone2',
    'video', 'help', 'share', 'order', 'tab_products', 'tab_khata', 'tab_hisaab', 'tab_more',
];

/** The steps in [$raw] (step => seconds) that are known, with sane seconds (-1, or 0 to ten years). */
function clean_steps(mixed $raw): array
{
    if (!is_array($raw)) {
        return [];
    }
    $out = [];
    foreach ($raw as $name => $secs) {
        if (!is_string($name) || !in_array($name, STEP_NAMES, true) || !is_numeric($secs)) {
            continue;
        }
        $out[$name] = max(-1, min(315_360_000, (int)$secs));
    }
    return $out;
}

function steps_table(bool $sqlite): string
{
    $tail = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    // One row per installation and step: the first time it was sent (at) and what the app said (secs).
    return "CREATE TABLE IF NOT EXISTS install_steps (
        install_id CHAR(36) NOT NULL,
        step VARCHAR(20) NOT NULL,
        secs INT NOT NULL,
        at DATETIME NOT NULL,
        PRIMARY KEY (install_id, step)
    )$tail";
}

/** The first version of Tillo Mobile that sends steps (0.9.9): installations from it on are counted in the funnel. */
const STEPS_FROM_CODE = 46;

/**
 * Keeps the steps of [$installId] not kept yet (a step sent again changes nothing), and says how many were new. The
 * table is made the first time it is needed. Never fails a check-in: a step not saved now comes again with the next one.
 */
function save_steps(string $installId, array $steps): int
{
    if ($steps === []) {
        return 0;
    }
    $sqlite = is_sqlite();
    $sql = ($sqlite ? 'INSERT OR IGNORE' : 'INSERT IGNORE') . ' INTO install_steps (install_id, step, secs, at) VALUES '
        . implode(', ', array_fill(0, count($steps), '(?, ?, ?, ?)'));
    $params = [];
    $now = now_text();
    foreach ($steps as $name => $secs) {
        array_push($params, $installId, $name, $secs, $now);
    }
    try {
        $statement = db()->prepare($sql);
        $statement->execute($params);
        return $statement->rowCount();
    } catch (PDOException) {
        try {
            db()->exec(steps_table($sqlite));
            $statement = db()->prepare($sql);
            $statement->execute($params);
            return $statement->rowCount();
        } catch (PDOException) {
            // Comes again with the next check-in.
            return 0;
        }
    }
}
