<?php
// POST /api/licensing: Tillo Licensing (the developer's key-making tool) connects with the support password, once, and
// gets the token it sends license keys with (/api/licenses). Connecting again makes a new token; the old one stops working.
//
// {"password": "<the support password>"}  →  {"ok": true, "token": "<64 hex>"}

declare(strict_types=1);

require __DIR__ . '/../lib/licensing.php';
require __DIR__ . '/../lib/schema.php';

$data = read_json();
$keys = ['support', 'ip:' . client_ip()];
if (throttled($keys)) {
    json_error(429, 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.');
}
$hash = (string)(config()['support_hash'] ?? '');
if ($hash === '' || !password_verify((string)($data['password'] ?? ''), $hash)) {
    record_failure($keys);
    json_error(403, 'That is not the support password.');
}

// The licenses table, on a database set up before it existed (the same as "Update database tables" on /support).
migrate(db());

$token = token(32);
$config = config();
$config['licensing_token_hash'] = hash('sha256', $token);
$config['licensing_connected_at'] = now_text();
write_config($config);
json_out(200, ['ok' => true, 'token' => $token]);
