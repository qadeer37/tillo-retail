<?php
// /food/privacy: the privacy policy of Tillo Food, the restaurant app on Google Play (com.tillopro.food). Google Play
// links to it from the store listing. Keep it in step with the app's Data safety form in Play Console.

declare(strict_types=1);

require __DIR__ . '/../lib/view.php';

page_start('Tillo Food privacy policy', ['body' => 'page-login']);
?>
<section class="login delete-account privacy">
    <h1>Privacy policy</h1>
    <p class="lead">For <strong>Tillo Food</strong> (Tillo Food – Restaurant POS), the Android app on Google Play, made by
        Tillo Retail, Pakistan. Last updated 22 October 2026.</p>

    <p>Tillo Food is a point of sale for restaurants. The restaurant's menu, orders, bills, tables, customers and day
        closing are kept on the restaurant's own phone or tablet. Nothing leaves it unless the restaurant turns on the
        Google backup below.</p>

    <h2>What stays on the phone</h2>
    <ul>
        <li><strong>Restaurant data:</strong> the menu, orders and bills, tables, payments, the day's hisaab and the
            galla counts, settings.</li>
        <li><strong>Delivery and pickup customers:</strong> the name, phone number and address the restaurant types in,
            so the next order finds them.</li>
        <li><strong>Bluetooth:</strong> used only to find and print to the restaurant's receipt printer. On Android 11
            and older, Android requires location permission for this; Tillo Food never reads the phone's location.</li>
        <li><strong>WhatsApp, phone and maps:</strong> a bill is handed to WhatsApp for the restaurant to send, and a
            customer's number or address is handed to the phone's dialer or maps app when the restaurant taps Call or
            Map. Tillo Food does not read or keep messages or calls.</li>
        <li><strong>App lock:</strong> the fingerprint or face is checked by Android; Tillo Food never sees it. The PIN
            is kept on the phone.</li>
    </ul>

    <h2>Optional: Google backup</h2>
    <p>If the restaurant turns on backup, Tillo Food signs in with the restaurant's Google account and saves a copy of
        its data in a hidden folder of that account's own Google Drive. Tillo Food uses the account's email address
        only to show which account is used. The backup goes to Google, not to Tillo, under Google's privacy policy; the
        restaurant can delete it in Google Drive › Settings › Manage apps. Android's own backup of apps may also keep a
        copy in the phone's Google account.</p>

    <h2>What Tillo Food does not do</h2>
    <ul>
        <li>No account with Tillo, no online reports, and no servers of ours that receive the restaurant's data.</li>
        <li>No ads, and no advertising, analytics or tracking libraries.</li>
        <li>Tillo never sells data, and shares it with no one.</li>
        <li>Tillo Food is made for restaurant owners and their staff, and is not meant for children.</li>
    </ul>

    <h2>Keeping and deleting data</h2>
    <p>The data stays on the phone until the restaurant deletes it: More › Reset Tillo starts fresh, and uninstalling
        the app deletes everything on the phone. The Google backup stays in the restaurant's Google Drive until it is
        deleted there.</p>

    <h2>Questions</h2>
    <p>WhatsApp or call <a href="https://wa.me/923123245056">0312-3245056</a>, or email
        <a href="mailto:tilloretail@gmail.com">tilloretail@gmail.com</a>. If this policy changes, the new version is
        posted on this page with its date.</p>
</section>
<?php
page_end();
