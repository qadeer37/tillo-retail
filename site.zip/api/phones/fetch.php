<?php
// POST /api/phones/fetch: a phone fetches a product photo another phone sent. {"name": "<photo>"}
// Authorization: Bearer <phone token>. The answer is the photo's bytes (404 when it isn't here). Deleted once every
// other phone has it.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$data = read_json();
$storeId = (int)$phone['store_id'];
$name = photo_name($data['name'] ?? null);
$file = $name === null ? '' : photo_file($storeId, $name);
if ($file === '' || !is_file($file)) {
    json_error(404, 'That photo is not here.');
}
$bytes = (string)file_get_contents($file);
$info = photo_info($storeId, $name);
if (!in_array($phone['letter'], $info['got'], true)) {
    $info['got'][] = $phone['letter'];
    save_photo_info($storeId, $name, $info);
}
delete_photo_if_done($storeId, $name);
header('Content-Type: application/octet-stream');
header('Cache-Control: no-store');
header('Content-Length: ' . strlen($bytes));
echo $bytes;
