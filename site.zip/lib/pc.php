<?php
// Tillo on computer (my.tillopro.com/pc): a computer joins a shop like another phone does. The computer can't scan, so
// the QR goes the other way: the computer shows a pair code (as a link, so Google Lens or the phone's camera opens
// Tillo with it), the shop's main phone scans it, makes a join code as it does for a new phone, and hands it to the
// pair; the computer, polling with its secret, takes the join code and joins through /api/phones/join. Nothing else
// is kept: the join code is cleared once the computer has it, and pairs are deleted an hour after they run out.

declare(strict_types=1);

require_once __DIR__ . '/phones.php';

/** How long a pair code shown on a computer works; the computer shows a new one after. */
const PC_PAIR_SECONDS = 300;
/** Pair codes one network may ask for in an hour (a computer left waiting asks for 12). */
const PC_PAIRS_PER_HOUR = 60;
/** The address the QR carries: Tillo on the phone opens it (Android App Link); anything else opens the page. */
const PC_LINK = 'https://my.tillopro.com/pc/';

/** The pair for a pair code (32 hex, or the link carrying it), or null. */
function pc_pair(mixed $pair): ?array
{
    $code = strtolower(trim((string)$pair));
    if (str_starts_with($code, PC_LINK)) {
        $code = rtrim(substr($code, strlen(PC_LINK)), '/');
    }
    if (!preg_match('/^[0-9a-f]{32}$/', $code)) {
        return null;
    }
    $row = q('SELECT * FROM pc_pairs WHERE pair_hash = ?', [hash('sha256', $code)])->fetch();
    return $row ?: null;
}

/** Deletes pairs that ran out more than an hour ago. */
function pc_delete_old(): void
{
    q('DELETE FROM pc_pairs WHERE expires_at < ?', [time() - 3600]);
}
