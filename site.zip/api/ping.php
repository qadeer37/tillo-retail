<?php
// POST /api/ping: an installed Tillo app checking in, so support can see which shops use Tillo (/active). No sign-in:
// the app sends a random id it made for itself, its version, the shop's name, city and kind, and counts (products,
// bills today and in the last 7 days; never amounts). A row per installation; at most one update in 10 minutes.
// Tillo Mobile 0.9.9 on also sends its steps (lib/steps.php), kept at once: a new step comes with an early check-in.

declare(strict_types=1);

require __DIR__ . '/../lib/bootstrap.php';
require __DIR__ . '/../lib/insights.php';

$data = read_json();
$id = strtolower((string)($data['install_id'] ?? ''));
if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $id)) {
    json_error(400, 'install_id is missing.');
}
$app = (string)($data['app'] ?? '');
if (!in_array($app, ['mobile', 'retail', 'food', 'repair', 'school'], true)) {
    json_error(400, 'Unknown app.');
}
$steps = clean_steps($data['steps'] ?? null);

// Once the app has its answer: the insights report, when it is due (lib/insights.php).
register_shutdown_function(function (): void {
    if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request();
    } elseif (function_exists('litespeed_finish_request')) {
        @litespeed_finish_request();
    }
    insights_snapshot();
});

$int = fn(string $k, int $max) => max(0, min($max, (int)($data[$k] ?? 0)));
$letter = strtoupper((string)($data['phone_letter'] ?? ''));
$values = [
    'app' => $app,
    'app_version' => clip($data['app_version'] ?? null, 20),
    'version_code' => $int('version_code', 2_000_000_000),
    'android' => $int('android', 999),
    'shop_name' => clip($data['shop_name'] ?? null, 120),
    'city' => clip($data['city'] ?? null, 80),
    'kind' => clip($data['kind'] ?? null, 40),
    'lang' => clip($data['lang'] ?? null, 5),
    'phone_letter' => preg_match('/^[A-E]$/', $letter) ? $letter : null,
    'phones' => max(1, $int('phones', 9)),
    'products' => $int('products', 10_000_000),
    'bills_today' => $int('bills_today', 1_000_000),
    'bills_7d' => $int('bills_7d', 10_000_000),
    'last_sale_date' => valid_date($data['last_sale_date'] ?? null),
    'backup' => empty($data['backup']) ? 0 : 1,
    'online' => empty($data['online']) ? 0 : 1,
];

$now = now_text();
$row = q('SELECT id, last_seen FROM installs WHERE install_id = ?', [$id])->fetch();
if ($row === false) {
    // New rows: at most 50 a day from one address (a shop's Wi-Fi has a few phones; more is someone filling the table).
    $key = 'ping:' . client_ip();
    if ((int)q('SELECT COUNT(*) FROM login_attempts WHERE k = ? AND at > ?', [$key, time() - 86400])->fetchColumn() >= 50) {
        json_out(200, ['ok' => true]);
    }
    q('INSERT INTO login_attempts (k, at) VALUES (?, ?)', [$key, time()]);
    $cols = array_keys($values);
    $sql = 'INSERT INTO installs (install_id, ' . implode(', ', $cols) . ', pings, days_seen, first_seen, last_seen) VALUES (?, '
        . implode(', ', array_fill(0, count($cols), '?')) . ', 1, 1, ?, ?)';
    try {
        q($sql, array_merge([$id], array_values($values), [$now, $now]));
    } catch (PDOException $e) {
        // Two check-ins at once: the other one made the row.
    }
    save_steps($id, $steps);
    json_out(200, ['ok' => true]);
}
// Before the 10-minute rule: a step comes with an early check-in, and counts at once. A check-in with a new step also
// brings the row up to date (the kind of shop just chosen, its first products).
$newSteps = save_steps($id, $steps);
if ($newSteps === 0 && strtotime((string)$row['last_seen']) > time() - 600) {
    json_out(200, ['ok' => true]);
}
$newDay = substr((string)$row['last_seen'], 0, 10) !== substr($now, 0, 10) ? 1 : 0;
$set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($values)));
q("UPDATE installs SET $set, pings = pings + 1, days_seen = days_seen + ?, last_seen = ? WHERE id = ?",
    array_merge(array_values($values), [$newDay, $now, (int)$row['id']]));
json_out(200, ['ok' => true]);
