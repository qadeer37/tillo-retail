<?php
// POST /api/account: Tillo Retail changes the shop's sign-in (a new password, a new mobile number) or its name.
// Authorization: Bearer <token>. Every field is optional: {"phone": "...", "password": "...", "name": "...", ...}
// The shop doesn't need the old password: having the token proves it is the shop.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';

$store = api_store();
$data = read_json();

$sets = [];
$params = [];

if (array_key_exists('phone', $data)) {
    $phone = normalize_phone((string)$data['phone']);
    if ($phone === '') {
        json_error(400, 'Enter a mobile number, like 0300-1234567.');
    }
    $sets[] = 'phone = ?';
    $params[] = $phone;
}
if (array_key_exists('password', $data)) {
    $password = (string)$data['password'];
    if ($problem = password_problem($password)) {
        json_error(400, $problem);
    }
    $sets[] = 'password_hash = ?';
    $params[] = password_hash($password, PASSWORD_DEFAULT);
}
foreach (['name' => 120, 'name_ur' => 120, 'city' => 80] as $field => $length) {
    if (array_key_exists($field, $data)) {
        $value = clip($data[$field], $length);
        if ($field === 'name' && $value === null) {
            continue;
        }
        $sets[] = "$field = ?";
        $params[] = $value;
    }
}

if ($sets) {
    $params[] = $store['id'];
    q('UPDATE stores SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
}

$phone = (string)q('SELECT phone FROM stores WHERE id = ?', [$store['id']])->fetchColumn();
json_out(200, ['ok' => true, 'phone' => show_phone($phone)]);
