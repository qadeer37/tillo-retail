<?php
// The numbers on the reports page. Every query is plain SQL that runs on MySQL and SQLite.
// Like the app: voided bills count nowhere, returns are taken off sales, profit is after returns.

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/** The period asked for: [from, to, preset, label]. */
function report_period(array $query): array
{
    $today = date('Y-m-d');
    $preset = (string)($query['p'] ?? 'today');
    $from = $to = $today;
    switch ($preset) {
        case 'yesterday':
            $from = $to = date('Y-m-d', strtotime('-1 day'));
            break;
        case '7d':
            $from = date('Y-m-d', strtotime('-6 days'));
            break;
        case '30d':
            $from = date('Y-m-d', strtotime('-29 days'));
            break;
        case 'month':
            $from = date('Y-m-01');
            break;
        case 'lastmonth':
            $from = date('Y-m-01', strtotime('first day of last month'));
            $to = date('Y-m-t', strtotime('first day of last month'));
            break;
        case 'custom':
            $from = valid_date($query['from'] ?? null) ?? $today;
            $to = valid_date($query['to'] ?? null) ?? $from;
            if ($to < $from) {
                [$from, $to] = [$to, $from];
            }
            if ((strtotime($to) - strtotime($from)) / 86400 >= MAX_REPORT_DAYS) {
                $from = date('Y-m-d', strtotime($to . ' -' . (MAX_REPORT_DAYS - 1) . ' days'));
            }
            break;
        default:
            $preset = 'today';
    }
    $label = $from === $to ? nice_day($from) : nice_day($from) . ' – ' . nice_day($to);
    return [$from, $to, $preset, $label];
}

function nice_day(string $date): string
{
    if ($date === date('Y-m-d')) {
        return 'Today';
    }
    if ($date === date('Y-m-d', strtotime('-1 day'))) {
        return 'Yesterday';
    }
    return date(date('Y', strtotime($date)) === date('Y') ? 'j M' : 'j M Y', strtotime($date));
}

/** Sales, returns and voids in the period. */
function report_totals(int $store, string $from, string $to): array
{
    $rows = q('SELECT type, COUNT(*) AS n, SUM(total) AS total, SUM(discount) AS discount, SUM(tax) AS tax, SUM(profit) AS profit,
                SUM(credit) AS credit, SUM(fee) AS fee
            FROM sales WHERE store_id = ? AND business_date BETWEEN ? AND ? AND status = 1 GROUP BY type', [$store, $from, $to])->fetchAll();
    $sale = ['n' => 0, 'total' => 0, 'discount' => 0, 'tax' => 0, 'profit' => 0, 'credit' => 0, 'fee' => 0];
    $return = $sale;
    foreach ($rows as $row) {
        $row = array_map('floatval', $row);
        if ((int)$row['type'] === 2) {
            $return = $row;
        } else {
            $sale = $row;
        }
    }
    $voided = q('SELECT COUNT(*) AS n, SUM(total) AS total FROM sales WHERE store_id = ? AND business_date BETWEEN ? AND ? AND status = 2',
        [$store, $from, $to])->fetch();

    $net = $sale['total'] - $return['total'];
    return [
        'sales' => $sale['total'],
        'bills' => (int)$sale['n'],
        'returns' => $return['total'],
        'return_count' => (int)$return['n'],
        'net' => $net,
        'average' => $sale['n'] > 0 ? $sale['total'] / $sale['n'] : 0,
        'profit' => $sale['profit'] - $return['profit'],
        'margin' => $net > 0 ? ($sale['profit'] - $return['profit']) / $net * 100 : null,
        'discount' => $sale['discount'],
        'tax' => $sale['tax'] - $return['tax'],
        'credit' => $sale['credit'] - $return['credit'],
        'voided' => (int)($voided['n'] ?? 0),
        'voided_total' => (float)($voided['total'] ?? 0),
    ];
}

/** Money taken by payment method (refunds taken off). */
function report_payments(int $store, string $from, string $to): array
{
    return q('SELECT p.method, SUM(CASE WHEN s.type = 2 THEN -p.amount ELSE p.amount END) AS amount, COUNT(*) AS n
            FROM sale_payments p JOIN sales s ON s.store_id = p.store_id AND s.sale_id = p.sale_id
            WHERE s.store_id = ? AND s.business_date BETWEEN ? AND ? AND s.status = 1
            GROUP BY p.method ORDER BY amount DESC', [$store, $from, $to])->fetchAll();
}

/** Net sales by hour (one day) or by day (a longer period): [[label, amount, key], ...]. */
function report_trend(int $store, string $from, string $to): array
{
    $net = 'SUM(CASE WHEN type = 2 THEN -total ELSE total END)';
    if ($from === $to) {
        $rows = q("SELECT hour AS k, $net AS amount FROM sales WHERE store_id = ? AND business_date = ? AND status = 1 GROUP BY hour",
            [$store, $from])->fetchAll();
        $byHour = array_column($rows, 'amount', 'k');
        if (!$byHour) {
            return [];
        }
        $first = min(8, min(array_keys($byHour)));
        $last = max(21, max(array_keys($byHour)));
        $points = [];
        for ($hour = $first; $hour <= $last; $hour++) {
            $points[] = [date('ga', mktime($hour, 0, 0)), (float)($byHour[$hour] ?? 0), (string)$hour];
        }
        return $points;
    }

    $rows = q("SELECT business_date AS k, $net AS amount FROM sales WHERE store_id = ? AND business_date BETWEEN ? AND ? AND status = 1
            GROUP BY business_date", [$store, $from, $to])->fetchAll();
    $byDay = [];
    foreach ($rows as $row) {
        $byDay[substr((string)$row['k'], 0, 10)] = (float)$row['amount'];
    }
    $points = [];
    $days = (int)round((strtotime($to) - strtotime($from)) / 86400) + 1;
    for ($i = 0; $i < $days; $i++) {
        $day = date('Y-m-d', strtotime($from . " +$i days"));
        $points[] = [$days <= 7 ? date('D j', strtotime($day)) : date('j M', strtotime($day)), $byDay[$day] ?? 0.0, $day];
    }
    return $points;
}

/** Best-selling products by amount (returns taken off). */
function report_products(int $store, string $from, string $to, int $limit): array
{
    $limit = max(1, min($limit, 1000));
    return q("SELECT l.product, MAX(l.product_ur) AS product_ur, l.unit,
                SUM(CASE WHEN s.type = 2 THEN -l.qty ELSE l.qty END) AS qty,
                SUM(CASE WHEN s.type = 2 THEN -l.amount ELSE l.amount END) AS amount,
                SUM(CASE WHEN s.type = 2 THEN -l.profit ELSE l.profit END) AS profit
            FROM sale_lines l JOIN sales s ON s.store_id = l.store_id AND s.sale_id = l.sale_id
            WHERE s.store_id = ? AND s.business_date BETWEEN ? AND ? AND s.status = 1
            GROUP BY l.product, l.unit ORDER BY amount DESC LIMIT $limit", [$store, $from, $to])->fetchAll();
}

function report_categories(int $store, string $from, string $to): array
{
    return q("SELECT COALESCE(l.category, 'No category') AS category,
                SUM(CASE WHEN s.type = 2 THEN -l.amount ELSE l.amount END) AS amount,
                SUM(CASE WHEN s.type = 2 THEN -l.profit ELSE l.profit END) AS profit
            FROM sale_lines l JOIN sales s ON s.store_id = l.store_id AND s.sale_id = l.sale_id
            WHERE s.store_id = ? AND s.business_date BETWEEN ? AND ? AND s.status = 1
            GROUP BY COALESCE(l.category, 'No category') ORDER BY amount DESC", [$store, $from, $to])->fetchAll();
}

function report_cashiers(int $store, string $from, string $to): array
{
    return q("SELECT COALESCE(cashier, '-') AS cashier, SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS bills,
                SUM(CASE WHEN type = 2 THEN -total ELSE total END) AS amount
            FROM sales WHERE store_id = ? AND business_date BETWEEN ? AND ? AND status = 1
            GROUP BY COALESCE(cashier, '-') ORDER BY amount DESC", [$store, $from, $to])->fetchAll();
}

/** Bills in the period, newest first. */
function report_bills(int $store, string $from, string $to, int $limit): array
{
    $limit = max(1, min($limit, 2000));
    return q("SELECT sale_id, number, type, status, local_time, cashier, customer, line_count, total, credit
            FROM sales WHERE store_id = ? AND business_date BETWEEN ? AND ?
            ORDER BY local_time DESC, sale_id DESC LIMIT $limit", [$store, $from, $to])->fetchAll();
}

function report_purchases(int $store, string $from, string $to): array
{
    return q('SELECT receipt_id, number, received_date, supplier, bill_no, line_count, total, paid
            FROM purchases WHERE store_id = ? AND received_date BETWEEN ? AND ? ORDER BY received_date DESC, receipt_id DESC',
        [$store, $from, $to])->fetchAll();
}
