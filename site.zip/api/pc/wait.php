<?php
// POST /api/pc/wait: the computer asks, every few seconds, whether the main phone let it join.
// {"pair": "<32 hex>", "secret": "<64 hex>"}. Answers {"ok", "ready": false, "expires_in"} while waiting; once, when
// let in: {"ok", "ready": true, "code": "TILLO-JOIN:<32 hex>", "name", "shop": {"name", "name_ur"}}; the computer then
// joins with /api/phones/join and downloads the copy of the shop. A code that ran out: 410 (show a new one).

declare(strict_types=1);

require __DIR__ . '/../../lib/pc.php';

$data = read_json();
$keys = ['pc-wait:' . client_ip()];
if (throttled($keys)) {
    json_error(429, 'Too many tries. Wait ' . THROTTLE_MINUTES . ' minutes and try again.');
}
$pair = pc_pair($data['pair'] ?? null);
$secret = strtolower(trim((string)($data['secret'] ?? '')));
if (!$pair || !preg_match('/^[0-9a-f]{64}$/', $secret) || !hash_equals($pair['secret_hash'], hash('sha256', $secret))) {
    record_failure($keys);
    json_error(404, 'This code is not known. Show a new one.');
}
if ($pair['taken_at'] !== null) {
    json_out(410, ['ok' => false, 'expired' => true, 'error' => 'This code was used already. Show a new one.']);
}
if ($pair['approved_at'] === null) {
    $left = (int)$pair['expires_at'] - time();
    if ($left <= 0) {
        json_out(410, ['ok' => false, 'expired' => true, 'error' => 'This code ran out. Show a new one.']);
    }
    json_out(200, ['ok' => true, 'ready' => false, 'expires_in' => $left]);
}
$store = q('SELECT name, name_ur FROM stores WHERE id = ?', [(int)$pair['store_id']])->fetch();
// Given once: the join code leaves this table now.
$took = q('UPDATE pc_pairs SET join_code = NULL, taken_at = ? WHERE pair_hash = ? AND taken_at IS NULL', [time(), $pair['pair_hash']])->rowCount();
if ($took !== 1 || $pair['join_code'] === null) {
    json_out(410, ['ok' => false, 'expired' => true, 'error' => 'This code was used already. Show a new one.']);
}
json_out(200, [
    'ok' => true,
    'ready' => true,
    'code' => 'TILLO-JOIN:' . $pair['join_code'],
    'name' => $pair['name'],
    'shop' => ['name' => $store['name'] ?? '', 'name_ur' => $store['name_ur'] ?? null],
]);
