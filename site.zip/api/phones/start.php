<?php
// POST /api/phones/start: the main phone gets ready to add a second phone (More > Phones > Add a phone).
// Authorization: Bearer <the shop's token> (the one online reports use). {"name": "This phone"}
// Answers {"ok", "phone_token" (64 hex, kept by the app), "letter": "A", "phones": [...]}. Asking again gives a new
// token (the answer may have been lost on a bad connection); the old one stops working.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$store = api_store();
$data = read_json();
$storeId = (int)$store['id'];
$name = clip($data['name'] ?? null, 60) ?? 'Main phone';

$token = token();
$existing = q("SELECT id FROM phone_links WHERE store_id = ? AND letter = 'A'", [$storeId])->fetch();
if ($existing) {
    q('UPDATE phone_links SET token_hash = ?, name = ?, last_seen_at = ? WHERE id = ?', [hash('sha256', $token), $name, time(), $existing['id']]);
} else {
    q("INSERT INTO phone_links (store_id, letter, name, token_hash, acked_seq, expired, joined_at, last_seen_at) VALUES (?, 'A', ?, ?, 0, 0, ?, ?)",
        [$storeId, $name, hash('sha256', $token), now_text(), time()]);
}
json_out(200, ['ok' => true, 'phone_token' => $token, 'letter' => 'A', 'phones' => phone_list($storeId)]);
