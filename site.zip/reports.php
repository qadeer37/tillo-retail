<?php
// The owner's reports: sales, profit, payments, best sellers, bills and goods received for a day or a period.
// ?s=<store>&p=today|yesterday|7d|30d|month|lastmonth|custom&from=&to=&all=products|bills

declare(strict_types=1);

require __DIR__ . '/lib/view.php';
require __DIR__ . '/lib/reports.php';

$stores = require_owner();
$storeId = isset($_GET['s']) && isset($stores[(int)$_GET['s']]) ? (int)$_GET['s'] : (int)array_key_first($stores);
$store = $stores[$storeId];
[$from, $to, $preset, $label] = report_period($_GET);
$all = (string)($_GET['all'] ?? '');

$totals = report_totals($storeId, $from, $to);
$payments = report_payments($storeId, $from, $to);
$trend = report_trend($storeId, $from, $to);
$products = report_products($storeId, $from, $to, $all === 'products' ? 1000 : 10);
$categories = report_categories($storeId, $from, $to);
$cashiers = report_cashiers($storeId, $from, $to);
$bills = report_bills($storeId, $from, $to, $all === 'bills' ? 2000 : 15);
$purchases = report_purchases($storeId, $from, $to);
$purchaseTotal = array_sum(array_map(fn($p) => (float)$p['total'], $purchases));

/** This page's address with some parameters changed. */
function link_to(array $change): string
{
    $params = array_merge($_GET, $change);
    $params = array_filter($params, fn($v) => $v !== null && $v !== '');
    return '/reports?' . http_build_query($params);
}

$nav = '<nav class="top-nav">';
if (count($stores) > 1) {
    $nav .= '<form method="get" action="/reports" class="store-pick"><select name="s" onchange="this.form.submit()" aria-label="Shop">';
    foreach ($stores as $id => $s) {
        $nav .= '<option value="' . $id . '"' . ($id === $storeId ? ' selected' : '') . '>' . h($s['name']) . '</option>';
    }
    $nav .= '</select><input type="hidden" name="p" value="' . h($preset) . '"></form>';
}
$nav .= '<a class="top-link" href="/logout">Sign out</a></nav>';

page_start($store['name'], ['nav' => $nav, 'body' => 'page-reports']);

$stale = $store['last_sync_at'] === null || strtotime($store['last_sync_at']) < time() - 6 * 3600;
$presets = ['today' => 'Today', 'yesterday' => 'Yesterday', '7d' => '7 days', '30d' => '30 days', 'month' => 'This month', 'lastmonth' => 'Last month'];
$maxTrend = max(array_merge([1], array_map(fn($p) => $p[1], $trend)));
$maxCategory = max(array_merge([1], array_map(fn($c) => (float)$c['amount'], $categories)));
?>
<div class="store-head">
    <h1><?= h($store['name']) ?></h1>
    <?php if ($store['name_ur']): ?><p class="ur" lang="ur" dir="rtl"><?= h($store['name_ur']) ?></p><?php endif ?>
    <p class="sync <?= $stale ? 'sync-old' : '' ?>">
        <?php if ($store['last_sync_at'] === null): ?>
            Nothing received from the shop yet. Sales show here a minute after they're made, while the shop's computer is online.
        <?php else: ?>
            Last update from the shop: <strong><?= h(ago($store['last_sync_at'])) ?></strong>.
            <?php if ($stale): ?>If the shop is open, check its main computer is on and has internet; sales made offline arrive as soon as it's back online.<?php endif ?>
        <?php endif ?>
    </p>
</div>

<nav class="periods" aria-label="Period">
    <?php foreach ($presets as $key => $name): ?>
        <a class="chip <?= $preset === $key ? 'on' : '' ?>" href="<?= h(link_to(['p' => $key, 'from' => null, 'to' => null, 'all' => null])) ?>"><?= h($name) ?></a>
    <?php endforeach ?>
    <form method="get" action="/reports" class="custom <?= $preset === 'custom' ? 'on' : '' ?>">
        <input type="hidden" name="s" value="<?= $storeId ?>"><input type="hidden" name="p" value="custom">
        <input type="date" name="from" value="<?= h($from) ?>" aria-label="From" max="<?= date('Y-m-d') ?>">
        <span>to</span>
        <input type="date" name="to" value="<?= h($to) ?>" aria-label="To" max="<?= date('Y-m-d') ?>">
        <button class="btn btn-small" type="submit">Show</button>
    </form>
</nav>

<h2 class="period-title"><?= h($label) ?></h2>

<section class="kpis">
    <div class="kpi kpi-main"><span>Net sales</span><strong><?= money($totals['net']) ?></strong>
        <small><?= num($totals['bills']) ?> bill<?= $totals['bills'] === 1 ? '' : 's' ?><?php if ($totals['bills'] > 0): ?> · average <?= money($totals['average']) ?><?php endif ?></small></div>
    <div class="kpi"><span>Profit</span><strong><?= money($totals['profit']) ?></strong>
        <small><?= $totals['margin'] === null ? '&nbsp;' : h(number_format($totals['margin'], 1)) . '% of sales' ?></small></div>
    <div class="kpi"><span>Given on khata</span><strong><?= money($totals['credit']) ?></strong><small>sold on credit</small></div>
    <div class="kpi"><span>Returns</span><strong><?= money($totals['returns']) ?></strong>
        <small><?= num($totals['return_count']) ?> return<?= $totals['return_count'] === 1 ? '' : 's' ?></small></div>
    <div class="kpi"><span>Discounts</span><strong><?= money($totals['discount']) ?></strong><small>given on bills</small></div>
    <div class="kpi"><span>Goods received</span><strong><?= money($purchaseTotal) ?></strong>
        <small><?= num(count($purchases)) ?> deliver<?= count($purchases) === 1 ? 'y' : 'ies' ?></small></div>
</section>
<?php if ($totals['voided'] > 0): ?>
    <p class="note"><?= num($totals['voided']) ?> bill<?= $totals['voided'] === 1 ? ' was' : 's were' ?> cancelled (<?= money($totals['voided_total']) ?>); cancelled bills are not counted above.</p>
<?php endif ?>

<?php if ($trend): ?>
<section class="card">
    <h3><?= $from === $to ? 'Sales by hour' : 'Sales by day' ?></h3>
    <div class="bars" role="img" aria-label="<?= $from === $to ? 'Sales by hour' : 'Sales by day' ?>">
        <?php foreach ($trend as [$name, $amount]): ?>
            <div class="bar" title="<?= h($name . ': ' . money($amount)) ?>">
                <span class="bar-value"><?= $amount > 0 ? h(short_amount($amount)) : '' ?></span>
                <span class="bar-fill" style="height:<?= max(0, round($amount / $maxTrend * 100, 1)) ?>%"></span>
                <span class="bar-label"><?= h($name) ?></span>
            </div>
        <?php endforeach ?>
    </div>
</section>
<?php endif ?>

<div class="grid-2">
    <section class="card">
        <h3>Payments</h3>
        <?php if (!$payments): ?><p class="empty">No sales in this period.</p><?php else: ?>
        <table class="table">
            <?php foreach ($payments as $p): ?>
                <tr><td><?= h($p['method']) ?></td><td class="num"><?= money($p['amount']) ?></td></tr>
            <?php endforeach ?>
        </table>
        <?php endif ?>
    </section>

    <section class="card">
        <h3>Categories</h3>
        <?php if (!$categories): ?><p class="empty">No sales in this period.</p><?php else: ?>
        <ul class="hbars">
            <?php foreach (array_slice($categories, 0, 8) as $c): ?>
                <li><span class="hb-name"><?= h($c['category']) ?></span><span class="hb-value"><?= money($c['amount']) ?></span>
                    <span class="hb-track"><span class="hb-fill" style="width:<?= max(0, round((float)$c['amount'] / $maxCategory * 100, 1)) ?>%"></span></span></li>
            <?php endforeach ?>
        </ul>
        <?php endif ?>
    </section>
</div>

<section class="card" id="products">
    <h3><?= $all === 'products' ? 'All products sold' : 'Best sellers' ?></h3>
    <?php if (!$products): ?><p class="empty">No sales in this period.</p><?php else: ?>
    <div class="table-scroll"><table class="table">
        <thead><tr><th>Product</th><th class="num wide">Sold</th><th class="num">Amount</th><th class="num wide">Profit</th></tr></thead>
        <tbody>
        <?php foreach ($products as $p): ?>
            <tr><td><?= h($p['product']) ?>
                    <div class="narrow muted small"><?= h(qty($p['qty'])) ?> <?= h($p['unit']) ?> sold · profit <?= money($p['profit']) ?></div></td>
                <td class="num wide"><?= h(qty($p['qty'])) ?> <span class="muted"><?= h($p['unit']) ?></span></td>
                <td class="num"><?= money($p['amount']) ?></td><td class="num muted wide"><?= money($p['profit']) ?></td></tr>
        <?php endforeach ?>
        </tbody>
    </table></div>
    <?php if ($all !== 'products' && count($products) >= 10): ?><a class="more" href="<?= h(link_to(['all' => 'products'])) ?>#products">All products</a><?php endif ?>
    <?php endif ?>
</section>

<section class="card" id="bills">
    <h3><?= $all === 'bills' ? 'All bills' : 'Latest bills' ?></h3>
    <?php if (!$bills): ?><p class="empty">No bills in this period.</p><?php else: ?>
    <div class="table-scroll"><table class="table bills">
        <thead><tr><th>Bill</th><th class="wide">Time</th><th>Customer</th><th class="num">Amount</th></tr></thead>
        <tbody>
        <?php foreach ($bills as $b): $url = '/sale?' . http_build_query(['s' => $storeId, 'id' => $b['sale_id'], 'back' => link_to([])]); ?>
            <tr class="<?= (int)$b['status'] === 2 ? 'voided' : '' ?>">
                <td><a href="<?= h($url) ?>">#<?= h((string)$b['number']) ?></a>
                    <?php if ((int)$b['type'] === 2): ?><span class="tag tag-return">Return</span><?php endif ?>
                    <?php if ((int)$b['status'] === 2): ?><span class="tag tag-void">Cancelled</span><?php endif ?>
                    <div class="narrow muted small nowrap"><?= h(date($from === $to ? 'g:i a' : 'j M, g:i a', strtotime($b['local_time']))) ?></div></td>
                <td class="muted wide nowrap"><?= h(date($from === $to ? 'g:i a' : 'j M, g:i a', strtotime($b['local_time']))) ?></td>
                <td><?= h($b['customer'] ?? '') ?><?php if ((float)$b['credit'] > 0): ?> <span class="tag">Khata</span><?php endif ?></td>
                <td class="num"><?= (int)$b['type'] === 2 ? '−' : '' ?><?= money($b['total']) ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table></div>
    <?php if ($all !== 'bills' && count($bills) >= 15): ?><a class="more" href="<?= h(link_to(['all' => 'bills'])) ?>#bills">All bills</a><?php endif ?>
    <?php endif ?>
</section>

<div class="grid-2">
    <section class="card">
        <h3>Cashiers</h3>
        <?php if (!$cashiers): ?><p class="empty">No sales in this period.</p><?php else: ?>
        <table class="table">
            <thead><tr><th>Cashier</th><th class="num">Bills</th><th class="num">Amount</th></tr></thead>
            <?php foreach ($cashiers as $c): ?>
                <tr><td><?= h($c['cashier']) ?></td><td class="num"><?= num($c['bills']) ?></td><td class="num"><?= money($c['amount']) ?></td></tr>
            <?php endforeach ?>
        </table>
        <?php endif ?>
    </section>

    <section class="card">
        <h3>Goods received</h3>
        <?php if (!$purchases): ?><p class="empty">No deliveries in this period.</p><?php else: ?>
        <table class="table">
            <thead><tr><th>Supplier</th><th class="num">Total</th><th class="num">Paid</th></tr></thead>
            <?php foreach (array_slice($purchases, 0, 30) as $p): ?>
                <tr><td><?= h($p['supplier'] ?? '-') ?><div class="muted small"><?= h(date('j M', strtotime($p['received_date']))) ?><?= $p['bill_no'] ? ' · Bill ' . h($p['bill_no']) : '' ?></div></td>
                    <td class="num"><?= money($p['total']) ?></td><td class="num muted"><?= money($p['paid']) ?></td></tr>
            <?php endforeach ?>
        </table>
        <?php endif ?>
    </section>
</div>
<?php
page_end();

/** 1,250 as 1.3k, 1,250,000 as 12.5 L, for the small labels on the bars. */
function short_amount(float $amount): string
{
    if ($amount >= 10000000) {
        return round($amount / 10000000, 1) . ' Cr';
    }
    if ($amount >= 100000) {
        return round($amount / 100000, 1) . ' L';
    }
    if ($amount >= 1000) {
        return round($amount / 1000, 1) . 'k';
    }
    return (string)round($amount);
}
