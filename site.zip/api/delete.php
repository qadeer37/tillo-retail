<?php
// POST /api/delete: the app deletes the shop's online account (More > Online reports > Delete my online account), with
// every sale, return and delivery it sent. Authorization: Bearer <token>. Owners can also do it on /delete.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';

$store = api_store();
read_json();
delete_store((int)$store['id']);
json_out(200, ['ok' => true]);
