<?php
// POST /api/pc/start: a computer wants to join a shop. {"device": "Chrome on Windows"}
// Answers {"ok", "pair" (32 hex, shown in the QR), "link" (the QR's text), "secret" (64 hex, kept by the computer
// only), "expires_in" (seconds)}. The computer asks for a new pair once this one runs out.

declare(strict_types=1);

require __DIR__ . '/../../lib/pc.php';

$data = read_json();
$ipHash = hash('sha256', 'pc:' . client_ip());
$recent = (int)q('SELECT COUNT(*) FROM pc_pairs WHERE ip_hash = ? AND created_at > ?', [$ipHash, time() - 3600])->fetchColumn();
if ($recent >= PC_PAIRS_PER_HOUR) {
    json_error(429, 'Too many codes from this network. Wait a few minutes and try again.');
}
pc_delete_old();
$pair = token(16);
$secret = token();
q('INSERT INTO pc_pairs (pair_hash, secret_hash, device, ip_hash, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)',
    [hash('sha256', $pair), hash('sha256', $secret), clip($data['device'] ?? null, 80), $ipHash, time(), time() + PC_PAIR_SECONDS]);
json_out(200, ['ok' => true, 'pair' => $pair, 'link' => PC_LINK . $pair, 'secret' => $secret, 'expires_in' => PC_PAIR_SECONDS]);
