<?php
// One bill: its items and how it was paid. ?s=<store>&id=<sale id>&back=<reports address>

declare(strict_types=1);

require __DIR__ . '/lib/view.php';

$stores = require_owner();
$storeId = (int)($_GET['s'] ?? 0);
$saleId = (int)($_GET['id'] ?? 0);
if (!isset($stores[$storeId])) {
    http_response_code(404);
    exit('Not found.');
}
$sale = q('SELECT * FROM sales WHERE store_id = ? AND sale_id = ?', [$storeId, $saleId])->fetch();
if (!$sale) {
    http_response_code(404);
    exit('Not found.');
}
$lines = q('SELECT * FROM sale_lines WHERE store_id = ? AND sale_id = ? ORDER BY line_no', [$storeId, $saleId])->fetchAll();
$payments = q('SELECT * FROM sale_payments WHERE store_id = ? AND sale_id = ? ORDER BY n', [$storeId, $saleId])->fetchAll();

$back = (string)($_GET['back'] ?? '');
if (!str_starts_with($back, '/reports')) {
    $back = '/reports?s=' . $storeId;
}
$isReturn = (int)$sale['type'] === 2;

page_start(($isReturn ? 'Return #' : 'Bill #') . $sale['number'], [
    'nav' => '<nav class="top-nav"><a class="top-link" href="' . h($back) . '">Back</a></nav>',
    'body' => 'page-sale',
]);
?>
<a class="back" href="<?= h($back) ?>">‹ Reports</a>
<section class="card receipt">
    <h1><?= $isReturn ? 'Return' : 'Bill' ?> #<?= h((string)$sale['number']) ?>
        <?php if ((int)$sale['status'] === 2): ?><span class="tag tag-void">Cancelled</span><?php endif ?></h1>
    <p class="muted"><?= h(date('D j M Y, g:i a', strtotime($sale['local_time']))) ?>
        <?= $sale['cashier'] ? ' · ' . h($sale['cashier']) : '' ?><?= $sale['register'] ? ' · ' . h($sale['register']) : '' ?></p>
    <?php if ($sale['customer']): ?><p>Customer: <strong><?= h($sale['customer']) ?></strong></p><?php endif ?>
    <?php if ($isReturn && $sale['original_number']): ?><p class="muted">From bill #<?= h((string)$sale['original_number']) ?></p><?php endif ?>
    <?php if ((int)$sale['status'] === 2): ?><p class="alert">Cancelled<?= $sale['void_reason'] ? ': ' . h($sale['void_reason']) : '' ?></p><?php endif ?>

    <table class="table">
        <thead><tr><th>Item</th><th class="num">Amount</th></tr></thead>
        <tbody>
        <?php foreach ($lines as $line): ?>
            <tr><td><?= h($line['product']) ?>
                    <div class="muted small"><?= h(qty($line['qty'])) ?> <?= h($line['unit'] ?? '') ?> × <?= num($line['price']) ?><?= (float)$line['discount'] > 0 ? ' · discount ' . num($line['discount']) : '' ?></div></td>
                <td class="num"><?= num($line['amount']) ?></td></tr>
        <?php endforeach ?>
        </tbody>
        <tfoot>
            <?php if ((float)$sale['discount'] > 0): ?><tr><td>Discount</td><td class="num">−<?= num($sale['discount']) ?></td></tr><?php endif ?>
            <?php if ((float)$sale['fee'] > 0): ?><tr><td>FBR POS fee</td><td class="num"><?= num($sale['fee']) ?></td></tr><?php endif ?>
            <tr class="total"><td><?= $isReturn ? 'Refund' : 'Total' ?></td><td class="num"><?= money($sale['total']) ?></td></tr>
            <?php foreach ($payments as $p): ?><tr><td class="muted"><?= h($p['method']) ?></td><td class="num muted"><?= num($p['amount']) ?></td></tr><?php endforeach ?>
            <?php if (!$isReturn): ?><tr><td class="muted">Profit</td><td class="num muted"><?= money($sale['profit']) ?></td></tr><?php endif ?>
        </tfoot>
    </table>
</section>
<?php
page_end();
