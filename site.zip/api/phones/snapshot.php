<?php
// POST /api/phones/snapshot: a phone that has just joined downloads the copy of the shop (the bytes the main phone
// sent). Authorization: Bearer <its token>. The copy is deleted once it is sent: if the download breaks, the main
// phone shows a new code.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
$join = q('SELECT code_hash FROM phone_joins WHERE store_id = ? AND used_at IS NOT NULL ORDER BY used_at DESC', [$storeId])->fetch();
$file = $join ? snapshot_file($storeId, $join['code_hash']) : '';
if ($phone['letter'] === 'A' || !$join || !is_file($file)) {
    json_error(404, 'The copy of the shop is not here any more. Scan a new code on the main phone.');
}
ignore_user_abort(true);
header('Content-Type: application/octet-stream');
header('Cache-Control: no-store');
header('Content-Length: ' . filesize($file));
readfile($file);
@unlink($file);
q('DELETE FROM phone_joins WHERE code_hash = ?', [$join['code_hash']]);
