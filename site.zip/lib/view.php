<?php
// The page frame shared by every screen.

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

const ASSET_VERSION = '5';

function page_start(string $title, array $options = []): void
{
    send_page_headers();
    $bodyClass = $options['body'] ?? '';
    $nav = $options['nav'] ?? '';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<meta name="robots" content="noindex">';
    echo '<meta name="theme-color" content="#0d3a23">';
    echo '<title>' . h($title) . ' · Tillo</title>';
    echo '<link rel="icon" href="https://tillopro.com/assets/img/favicon.svg" type="image/svg+xml">';
    echo '<link rel="stylesheet" href="/assets/app.css?v=' . ASSET_VERSION . '">';
    echo '</head><body class="' . h($bodyClass) . '">';
    echo '<header class="top"><div class="wrap top-row">';
    echo '<a class="brand" href="/"><span class="brand-mark">t</span><span class="brand-name">Tillo</span><span class="brand-sub">Reports</span></a>';
    echo $nav;
    echo '</div></header><main class="wrap">';
}

function page_end(): void
{
    echo '</main><footer class="foot wrap">Tillo Retail · <a href="https://tillopro.com">tillopro.com</a> · Help on WhatsApp <a href="https://wa.me/923123245056">0312-3245056</a></footer>';
    echo '</body></html>';
}

/** "2 minutes ago", "3 hours ago", "14 Oct, 9:05 pm". */
function ago(?string $time): string
{
    if ($time === null || $time === '') {
        return 'never';
    }
    $at = strtotime($time);
    $seconds = time() - $at;
    if ($seconds < 60) {
        return 'just now';
    }
    if ($seconds < 3600) {
        $m = intdiv($seconds, 60);
        return $m . ' minute' . ($m === 1 ? '' : 's') . ' ago';
    }
    if ($seconds < 86400) {
        $hours = intdiv($seconds, 3600);
        return $hours . ' hour' . ($hours === 1 ? '' : 's') . ' ago';
    }
    return date('j M, g:i a', $at);
}

function nice_date(string $date): string
{
    return date('D j M Y', strtotime($date));
}
