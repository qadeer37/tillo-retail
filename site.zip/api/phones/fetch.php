<?php
// POST /api/phones/fetch: a phone fetches a product photo the other phone sent. {"name": "<photo>"}
// Authorization: Bearer <phone token>. The answer is the photo's bytes (404 when it isn't here); it is deleted then.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$data = read_json();
$storeId = (int)$phone['store_id'];
$name = photo_name($data['name'] ?? null);
$file = $name === null ? '' : photo_file($storeId, $name);
if ($file === '' || !is_file($file)) {
    json_error(404, 'That photo is not here.');
}
$bytes = file_get_contents($file);
@unlink($file);
header('Content-Type: application/octet-stream');
header('Cache-Control: no-store');
header('Content-Length: ' . strlen((string)$bytes));
echo $bytes;
