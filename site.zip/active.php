<?php
// Tillo support: the shops using Tillo. Every installed app checks in when it is opened (api/ping, at most every few
// hours): this page counts the installations seen today, in 7 days and in 30, and lists them, the latest first, with
// the shop's name, city and kind, the app's version, and how busy the shop is (bills today and in 7 days; no amounts).

declare(strict_types=1);

require __DIR__ . '/lib/view.php';
require __DIR__ . '/lib/schema.php';

if (!is_support()) {
    header('Location: /support');
    exit;
}

const ACTIVE_PERIODS = ['today' => 'Today', '7' => '7 days', '30' => '30 days', 'all' => 'All'];
const ACTIVE_APPS = ['mobile' => 'Tillo Mobile', 'retail' => 'Tillo Retail'];

$period = (string)($_GET['p'] ?? '7');
$period = array_key_exists($period, ACTIVE_PERIODS) ? $period : '7';
$app = (string)($_GET['app'] ?? '');
$app = array_key_exists($app, ACTIVE_APPS) ? $app : '';
$search = trim((string)($_GET['q'] ?? ''));

$today = date('Y-m-d') . ' 00:00:00';
$since = [
    'today' => $today,
    '7' => date('Y-m-d H:i:s', time() - 7 * 86400),
    '30' => date('Y-m-d H:i:s', time() - 30 * 86400),
    'all' => '2000-01-01 00:00:00',
];

/** How many installations were seen since [$from] (of [$app], when given). */
function active_count(string $from, string $app, string $column = 'last_seen'): int
{
    $sql = "SELECT COUNT(*) FROM installs WHERE $column >= ?" . ($app !== '' ? ' AND app = ?' : '');
    return (int)q($sql, $app !== '' ? [$from, $app] : [$from])->fetchColumn();
}

try {
    $counts = [];
    foreach ($since as $k => $from) {
        $counts[$k] = active_count($from, $app);
    }
} catch (PDOException) {
    // The table isn't there yet: add it, as "Update database tables" on /support would.
    migrate(db());
    $counts = array_map(fn () => 0, $since);
}
$newWeek = active_count($since['7'], $app, 'first_seen');
$selling = (int)q('SELECT COUNT(*) FROM installs WHERE last_seen >= ? AND bills_7d > 0' . ($app !== '' ? ' AND app = ?' : ''),
    $app !== '' ? [$since['7'], $app] : [$since['7']])->fetchColumn();

$where = ['last_seen >= ?'];
$params = [$since[$period]];
if ($app !== '') {
    $where[] = 'app = ?';
    $params[] = $app;
}
if ($search !== '') {
    $where[] = '(shop_name LIKE ? OR city LIKE ? OR kind LIKE ?)';
    array_push($params, '%' . $search . '%', '%' . $search . '%', '%' . $search . '%');
}
$rows = q('SELECT * FROM installs WHERE ' . implode(' AND ', $where) . ' ORDER BY last_seen DESC LIMIT 300', $params)->fetchAll();
$versions = q('SELECT app, app_version, COUNT(*) AS n FROM installs WHERE last_seen >= ?' . ($app !== '' ? ' AND app = ?' : '')
    . ' GROUP BY app, app_version ORDER BY n DESC LIMIT 12', $app !== '' ? [$since['7'], $app] : [$since['7']])->fetchAll();

/** The address of this page with its filters. */
function active_link(string $period, string $app, string $search): string
{
    $query = http_build_query(array_filter(['p' => $period === '7' ? '' : $period, 'app' => $app, 'q' => $search], fn ($v) => $v !== ''));
    return '/active' . ($query === '' ? '' : '?' . $query);
}

$nav = '<nav class="top-nav"><a class="top-link" href="/support">Shops</a><a class="top-link" href="/licenses">License keys</a><form method="post" action="/support">'
    . csrf_field() . '<input type="hidden" name="action" value="signout"><button class="top-link linklike" type="submit">Sign out</button></form></nav>';
page_start('Active shops', ['nav' => $nav, 'body' => 'page-support']);
?>
<h1>Active shops</h1>
<p class="note">Each installed app checks in when it is opened (at most every few hours). One row per installation: a
    phone added to a shop (Phones) is its own row, marked B, C…</p>

<section class="kpis">
    <div class="kpi kpi-main"><span>Opened in the last 7 days</span><strong><?= num($counts['7']) ?></strong>
        <small><?= num($selling) ?> made a sale · <?= num($newWeek) ?> new this week</small></div>
    <div class="kpi"><span>Opened today</span><strong><?= num($counts['today']) ?></strong></div>
    <div class="kpi"><span>Last 30 days</span><strong><?= num($counts['30']) ?></strong><small><?= num($counts['all']) ?> ever</small></div>
</section>

<div class="periods">
    <?php foreach (ACTIVE_PERIODS as $k => $label): $k = (string)$k; // '7' and '30' come back as numbers ?>
        <a class="chip<?= $period === $k ? ' on' : '' ?>" href="<?= h(active_link($k, $app, $search)) ?>"><?= h($label) ?> · <?= num($counts[$k]) ?></a>
    <?php endforeach ?>
</div>
<div class="periods">
    <a class="chip<?= $app === '' ? ' on' : '' ?>" href="<?= h(active_link($period, '', $search)) ?>">All apps</a>
    <?php foreach (ACTIVE_APPS as $k => $label): ?>
        <a class="chip<?= $app === $k ? ' on' : '' ?>" href="<?= h(active_link($period, $k, $search)) ?>"><?= h($label) ?></a>
    <?php endforeach ?>
</div>

<form method="get" class="searchbar">
    <input type="search" name="q" value="<?= h($search) ?>" placeholder="Shop, city or kind" aria-label="Search">
    <?php if ($period !== '7'): ?><input type="hidden" name="p" value="<?= h($period) ?>"><?php endif ?>
    <?php if ($app !== ''): ?><input type="hidden" name="app" value="<?= h($app) ?>"><?php endif ?>
    <button class="btn btn-small" type="submit">Find</button>
</form>

<?php if ($rows): ?>
    <section class="card">
        <div class="table-scroll">
            <table class="table">
                <thead>
                <tr><th>Shop</th><th>Last opened</th><th>Bills today · 7 days</th><th>Products</th><th>Version</th><th>Since</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><strong><?= h($r['shop_name'] ?? 'No name yet') ?></strong><?= $r['phone_letter'] && $r['phone_letter'] !== 'A' ? ' <span class="tag">phone ' . h($r['phone_letter']) . '</span>' : '' ?>
                            <div class="muted small"><?= h(implode(' · ', array_filter([$r['city'], $r['kind'], $r['lang']]))) ?>
                                <?= (int)$r['phones'] > 1 ? ' · ' . num($r['phones']) . ' phones' : '' ?>
                                <?= $r['backup'] ? ' · backup' : '' ?><?= $r['online'] ? ' · online reports' : '' ?></div></td>
                        <td class="nowrap"><?= h(ago($r['last_seen'])) ?><div class="muted small"><?= num($r['days_seen']) ?> days used</div></td>
                        <td class="nowrap"><?= num($r['bills_today']) ?> · <?= num($r['bills_7d']) ?>
                            <?php if ($r['last_sale_date']): ?><div class="muted small">last sale <?= h(nice_date($r['last_sale_date'])) ?></div><?php endif ?></td>
                        <td><?= num($r['products']) ?></td>
                        <td class="nowrap"><span class="tag"><?= h($r['app']) ?></span> <?= h($r['app_version'] ?? '?') ?>
                            <?php if ($r['android']): ?><div class="muted small">Android API <?= (int)$r['android'] ?></div><?php endif ?></td>
                        <td class="nowrap"><?= h(date('j M Y', strtotime($r['first_seen']))) ?></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php if (count($rows) === 300): ?><p class="muted small">The latest 300 are shown. Search to find others.</p><?php endif ?>
    </section>
<?php else: ?>
    <p class="empty"><?= $search !== '' ? 'No shops found.' : 'No check-ins yet. They start when shops open the new version.' ?></p>
<?php endif ?>

<?php if ($versions): ?>
    <section class="card">
        <h3>Versions in use (last 7 days)</h3>
        <p><?php foreach ($versions as $v): ?><span class="chip"><?= h($v['app']) ?> <?= h($v['app_version'] ?? '?') ?> · <?= num($v['n']) ?></span> <?php endforeach ?></p>
    </section>
<?php endif ?>
<?php
page_end();
