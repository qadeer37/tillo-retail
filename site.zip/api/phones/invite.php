<?php
// POST /api/phones/invite?after=<seq>: the main phone sends a copy of the shop and gets a join code to show as a QR.
// Authorization: Bearer <phone A's token>. The body is the copy of the shop itself (the app's backup file, as bytes);
// "after" is the last change from the other phones that is in the copy (0 when it is the first other phone).
// Answers {"ok", "code" (32 hex), "qr": "TILLO-JOIN:<code>", "expires_in" (seconds)}. One use, 10 minutes; a new
// code replaces any earlier one. Refused (409) when the shop has 5 phones already.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$storeId = (int)$phone['store_id'];
if ($phone['letter'] !== 'A') {
    json_error(403, 'Only the main phone can add a phone.');
}
expire_quiet_phones($storeId);
if (count(active_phones($storeId)) >= MAX_PHONES) {
    json_error(409, 'This shop has ' . MAX_PHONES . ' phones already. Remove one first.');
}
$after = max(0, (int)($_GET['after'] ?? 0));
$bytes = read_bytes(MAX_SNAPSHOT_BYTES);
delete_old_joins($storeId, true);

$code = token(16);
$codeHash = hash('sha256', $code);
if (file_put_contents(snapshot_file($storeId, $codeHash), $bytes, LOCK_EX) === false) {
    json_error(500, 'Could not keep the copy of the shop. Try again.');
}
// The new phone takes the changes after the copy: kept for it until it joins (or the code runs out).
q('INSERT INTO phone_joins (code_hash, store_id, snapshot_seq, snapshot_bytes, expires_at, used_at) VALUES (?, ?, ?, ?, ?, NULL)',
    [$codeHash, $storeId, $after, strlen($bytes), time() + JOIN_SECONDS]);

json_out(200, ['ok' => true, 'code' => $code, 'qr' => 'TILLO-JOIN:' . $code, 'expires_in' => JOIN_SECONDS]);
