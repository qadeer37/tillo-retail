<?php
// POST /api/phones/sync: a phone sends its changes and takes the other phones'. Authorization: Bearer <phone token>.
//
// {"after": <the last seq it has applied from the other phones>,
//  "changes": [{"uid": "<the phone's own id for it>", "kind": "row", "body": "<JSON text>"}],
//  "want": ["<photo>", ...]}  (product photos it hasn't got)
//
// Answers {"ok", "me": "A", "changes": [{"seq", "uid", "kind", "body", "at"}], "more": bool, "phones": [...],
// "wanted": ["<photo>", ...]} (photos some phone asked for: send them if this phone has them).
// A change is deleted once every other phone has it. Sending the same change again (a lost answer) does nothing.
// Changes made when there is no other phone (and no code waiting) are not kept.

declare(strict_types=1);

require __DIR__ . '/../../lib/phones.php';

$phone = api_phone();
$data = read_json();
$storeId = (int)$phone['store_id'];
$me = $phone['letter'];
$after = max(0, (int)($data['after'] ?? 0));
$changes = is_array($data['changes'] ?? null) ? $data['changes'] : [];
if (count($changes) > MAX_CHANGES) {
    json_error(413, 'Too much at once; send it in smaller parts.');
}

expire_quiet_phones($storeId);
$keep = other_phones($storeId, $me) !== [] || waiting_join($storeId) !== null;

$pdo = db();
$pdo->beginTransaction();
try {
    $taken = 0;
    foreach ($changes as $change) {
        $uid = (string)($change['uid'] ?? '');
        $kind = (string)($change['kind'] ?? '');
        $body = $change['body'] ?? null;
        if (!preg_match('/^[A-Za-z0-9-]{8,40}$/', $uid) || !preg_match('/^[a-z_]{1,30}$/', $kind) || !is_string($body) || strlen($body) > 1000000) {
            continue;
        }
        $taken++;
        if (!$keep || q('SELECT 1 FROM phone_changes WHERE store_id = ? AND uid = ?', [$storeId, $uid])->fetchColumn()) {
            continue;
        }
        q('INSERT INTO phone_changes (store_id, from_letter, uid, kind, body, at) VALUES (?, ?, ?, ?, ?, ?)',
            [$storeId, $me, $uid, $kind, $body, time()]);
    }
    if ($after > (int)$phone['acked_seq']) {
        q('UPDATE phone_links SET acked_seq = ? WHERE id = ?', [$after, $phone['id']]);
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
}
// What every phone has applied is not needed any more.
delete_delivered($storeId);

// Photos: asked for by this phone, and still wanted by any phone.
$wants = photo_wants($storeId);
foreach (is_array($data['want'] ?? null) ? array_slice($data['want'], 0, 100) : [] as $name) {
    if (($name = photo_name($name)) !== null && !is_file(photo_file($storeId, $name))) {
        $wants[] = $name;
    }
}
$wants = array_values(array_filter(array_unique($wants), fn($n) => !is_file(photo_file($storeId, $n))));
save_photo_wants($storeId, $wants);

$rows = q('SELECT seq, uid, kind, body, at FROM phone_changes WHERE store_id = ? AND from_letter <> ? AND seq > ? ORDER BY seq LIMIT ' . (MAX_CHANGES + 1),
    [$storeId, $me, $after])->fetchAll();
$more = count($rows) > MAX_CHANGES;
$out = [];
foreach (array_slice($rows, 0, MAX_CHANGES) as $row) {
    $out[] = ['seq' => (int)$row['seq'], 'uid' => $row['uid'], 'kind' => $row['kind'], 'body' => $row['body'], 'at' => (int)$row['at']];
}
json_out(200, ['ok' => true, 'me' => $me, 'taken' => $taken, 'changes' => $out, 'more' => $more, 'phones' => phone_list($storeId), 'wanted' => array_slice($wants, 0, 50)]);
