<?php
// POST /api/sync: Tillo Retail sends sales, returns, voids and goods received. Authorization: Bearer <token>.
//
// {"store": {"name": "...", "name_ur": "...", "city": "...", "version": "..."},
//  "sales": [{"id", "number", "type" (1 sale, 2 return), "status" (1, or 2 voided), "date" (yyyy-mm-dd, the business
//             day), "time" (yyyy-mm-dd hh:mm:ss, the shop's time), "register", "cashier", "customer",
//             "original_number", "quantity", "gross", "discount", "tax", "fee", "rounding", "total", "credit",
//             "cost", "profit", "void_reason", "voided_at",
//             "lines": [{"product", "product_ur", "category", "unit", "qty", "price", "discount", "amount", "profit"}],
//             "payments": [{"method", "kind", "amount"}]}],
//  "voids": [{"id", "reason", "at"}],
//  "purchases": [{"id", "number", "date", "supplier", "bill_no", "subtotal", "discount", "other_charges", "total",
//                 "paid", "paid_with", "received_by",
//                 "lines": [{"product", "unit", "qty", "bonus", "cost", "amount"}]}]}
//
// Sending the same sale again replaces it, so the app can always resend after a lost answer.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';

const MAX_SALES = 500;
const MAX_PURCHASES = 200;
const MAX_VOIDS = 2000;
const MAX_LINES = 1000;

$store = api_store();
$data = read_json();
$storeId = (int)$store['id'];

$sales = is_array($data['sales'] ?? null) ? $data['sales'] : [];
$voids = is_array($data['voids'] ?? null) ? $data['voids'] : [];
$purchases = is_array($data['purchases'] ?? null) ? $data['purchases'] : [];
if (count($sales) > MAX_SALES || count($purchases) > MAX_PURCHASES || count($voids) > MAX_VOIDS) {
    json_error(413, 'Too much at once; send it in smaller parts.');
}

$pdo = db();
$pdo->beginTransaction();
try {
    $saleCount = 0;
    foreach ($sales as $sale) {
        if (save_sale($storeId, $sale)) {
            $saleCount++;
        }
    }

    $voidCount = 0;
    foreach ($voids as $void) {
        $id = (int)($void['id'] ?? 0);
        if ($id <= 0) {
            continue;
        }
        $voidCount += q('UPDATE sales SET status = 2, void_reason = ?, voided_at = ? WHERE store_id = ? AND sale_id = ?',
            [clip($void['reason'] ?? null, 300), valid_time($void['at'] ?? null), $storeId, $id])->rowCount();
    }

    $purchaseCount = 0;
    foreach ($purchases as $purchase) {
        if (save_purchase($storeId, $purchase)) {
            $purchaseCount++;
        }
    }

    $info = is_array($data['store'] ?? null) ? $data['store'] : [];
    q('UPDATE stores SET last_sync_at = ?, name = COALESCE(?, name), name_ur = ?, city = ?, app_version = COALESCE(?, app_version) WHERE id = ?', [
        now_text(), clip($info['name'] ?? null, 120), clip($info['name_ur'] ?? $store['name_ur'], 120),
        clip($info['city'] ?? $store['city'], 80), clip($info['version'] ?? null, 20), $storeId,
    ]);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('Tillo sync failed for store ' . $storeId . ': ' . $e->getMessage());
    json_error(500, 'The server couldn\'t save this; it will be sent again.');
}

json_out(200, ['ok' => true, 'sales' => $saleCount, 'voids' => $voidCount, 'purchases' => $purchaseCount]);

function save_sale(int $storeId, mixed $sale): bool
{
    if (!is_array($sale)) {
        return false;
    }
    $id = (int)($sale['id'] ?? 0);
    $date = valid_date($sale['date'] ?? null);
    $time = valid_time($sale['time'] ?? null);
    if ($id <= 0 || $date === null || $time === null) {
        return false;
    }
    $type = (int)($sale['type'] ?? 1) === 2 ? 2 : 1;
    $status = (int)($sale['status'] ?? 1) === 2 ? 2 : 1;
    $lines = is_array($sale['lines'] ?? null) ? array_slice($sale['lines'], 0, MAX_LINES) : [];
    $payments = is_array($sale['payments'] ?? null) ? array_slice($sale['payments'], 0, 50) : [];

    q('REPLACE INTO sales (store_id, sale_id, number, type, status, business_date, local_time, hour, register, cashier, customer,
        original_number, line_count, quantity, gross, discount, tax, fee, rounding, total, credit, cost, profit, void_reason, voided_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
        $storeId, $id, (int)($sale['number'] ?? 0), $type, $status, $date, $time, (int)substr($time, 11, 2),
        clip($sale['register'] ?? null, 60), clip($sale['cashier'] ?? null, 80), clip($sale['customer'] ?? null, 120),
        isset($sale['original_number']) ? (int)$sale['original_number'] : null, count($lines),
        dec($sale['quantity'] ?? 0), dec($sale['gross'] ?? 0), dec($sale['discount'] ?? 0), dec($sale['tax'] ?? 0),
        dec($sale['fee'] ?? 0), dec($sale['rounding'] ?? 0), dec($sale['total'] ?? 0), dec($sale['credit'] ?? 0),
        dec($sale['cost'] ?? 0), dec($sale['profit'] ?? 0),
        $status === 2 ? clip($sale['void_reason'] ?? null, 300) : null, $status === 2 ? valid_time($sale['voided_at'] ?? null) : null,
    ]);

    q('DELETE FROM sale_lines WHERE store_id = ? AND sale_id = ?', [$storeId, $id]);
    $n = 0;
    foreach ($lines as $line) {
        if (!is_array($line) || clip($line['product'] ?? null, 160) === null) {
            continue;
        }
        $n++;
        q('INSERT INTO sale_lines (store_id, sale_id, line_no, product, product_ur, category, unit, qty, price, discount, amount, profit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
            $storeId, $id, $n, clip($line['product'], 160), clip($line['product_ur'] ?? null, 160), clip($line['category'] ?? null, 80),
            clip($line['unit'] ?? null, 40), dec($line['qty'] ?? 0), dec($line['price'] ?? 0), dec($line['discount'] ?? 0),
            dec($line['amount'] ?? 0), dec($line['profit'] ?? 0),
        ]);
    }

    q('DELETE FROM sale_payments WHERE store_id = ? AND sale_id = ?', [$storeId, $id]);
    $n = 0;
    foreach ($payments as $payment) {
        if (!is_array($payment)) {
            continue;
        }
        $n++;
        q('INSERT INTO sale_payments (store_id, sale_id, n, method, kind, amount) VALUES (?, ?, ?, ?, ?, ?)', [
            $storeId, $id, $n, clip($payment['method'] ?? null, 60) ?? 'Other', (int)($payment['kind'] ?? 7), dec($payment['amount'] ?? 0),
        ]);
    }
    return true;
}

function save_purchase(int $storeId, mixed $purchase): bool
{
    if (!is_array($purchase)) {
        return false;
    }
    $id = (int)($purchase['id'] ?? 0);
    $date = valid_date($purchase['date'] ?? null);
    if ($id <= 0 || $date === null) {
        return false;
    }
    $lines = is_array($purchase['lines'] ?? null) ? array_slice($purchase['lines'], 0, MAX_LINES) : [];

    q('REPLACE INTO purchases (store_id, receipt_id, number, received_date, supplier, bill_no, line_count, subtotal, discount,
        other_charges, total, paid, paid_with, received_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
        $storeId, $id, (int)($purchase['number'] ?? 0), $date, clip($purchase['supplier'] ?? null, 120),
        clip($purchase['bill_no'] ?? null, 40), count($lines), dec($purchase['subtotal'] ?? 0), dec($purchase['discount'] ?? 0),
        dec($purchase['other_charges'] ?? 0), dec($purchase['total'] ?? 0), dec($purchase['paid'] ?? 0),
        clip($purchase['paid_with'] ?? null, 60), clip($purchase['received_by'] ?? null, 80),
    ]);

    q('DELETE FROM purchase_lines WHERE store_id = ? AND receipt_id = ?', [$storeId, $id]);
    $n = 0;
    foreach ($lines as $line) {
        if (!is_array($line) || clip($line['product'] ?? null, 160) === null) {
            continue;
        }
        $n++;
        q('INSERT INTO purchase_lines (store_id, receipt_id, line_no, product, unit, qty, bonus, cost, amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [
            $storeId, $id, $n, clip($line['product'], 160), clip($line['unit'] ?? null, 40), dec($line['qty'] ?? 0),
            dec($line['bonus'] ?? 0), dec($line['cost'] ?? 0), dec($line['amount'] ?? 0),
        ]);
    }
    return true;
}
