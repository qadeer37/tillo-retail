<?php
// GET /api/insights: how new installations of Tillo Mobile get on (lib/insights.php), for Tillo support signed in on
// /support; anyone else gets "not found". Plain text; ?format=json for the numbers, ?days=14 (1 to 60) for how far back.
// Counts and steps only: no shop names, cities, phone numbers or amounts.

declare(strict_types=1);

require __DIR__ . '/../lib/auth.php';
require __DIR__ . '/../lib/insights.php';

if (!is_support()) {
    http_response_code(404);
    exit;
}
$report = insights_report((int)($_GET['days'] ?? 14));
header('Cache-Control: no-store');
if (($_GET['format'] ?? '') === 'json') {
    json_out(200, $report);
}
header('Content-Type: text/plain; charset=utf-8');
echo insights_text($report);
